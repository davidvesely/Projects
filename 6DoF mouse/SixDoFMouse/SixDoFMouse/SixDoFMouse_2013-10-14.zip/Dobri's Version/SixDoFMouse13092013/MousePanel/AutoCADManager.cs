﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.Win32;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.GraphicsSystem;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CADBest.Geometry;

namespace SixDoFMouse
{
    public class AutoCADManager
    {
        #region Windows functions
        public static float ReadPrefScale()
        {
            RegistryKey sk1 = Registry.CurrentUser.OpenSubKey("Software\\CADBEST\\6DOF Mouse");
            float scale;
            if (sk1 != null)
            {
                scale = (float)Convert.ToDouble(sk1.GetValue("Scale"));
                if (scale == 0)
                    scale = 1;
            }
            else
                scale = 1;
            return scale;
        }

        public static Bitmap ResizeBitmap(float scale, Bitmap source)
        {
            int width, height;
            Bitmap bmp;
            Graphics graph;
            width = (int)(source.Width * scale);
            height = (int)(source.Height * scale);
            bmp = new Bitmap(width, height, source.PixelFormat);
            graph = Graphics.FromImage(bmp);
            graph.DrawImage(source, new Rectangle(0, 0, width, height));
            return bmp;
        }
        #endregion

        #region Thread safe optimization
        // This member is needed for transferring the processing of AutoCAD
        // environment from camera's thread to main thread of AutoCAD
        private static Control syncControl;

        // Delegates used for marshaling the call of corresponding method to main thread of AutoCAD
        private delegate void ModifyViewspaceDelegate(List<Point3D> ViewDesc);
        private delegate void DrawPolylinesDelegate(List<Point3D> Objects, bool ShouldDeletePrevious, Autodesk.AutoCAD.Colors.Color color);
        private delegate void DrawCoordinatesDelegate(List<List<Point3D>> Objects, bool ShouldDelete);

        private void InitializeSyncControl()
        {
            // The control created to help with marshaling
            // needs to be created on the main thread
            syncControl = new Control();
            syncControl.CreateControl();
        }
        #endregion

        #region AutoCAD functions
        // Used for saving the initial state of View
        private Vector3d _initialView;
        //private Document _doc;

        public AutoCADManager()
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            ViewTableRecord vtr = doc.Editor.GetCurrentView();
            _initialView = vtr.ViewDirection;

            InitializeSyncControl();
        }

        public void ModifyViewspace(List<Point3D> ViewDesc)
        {
            // If ModifyViewspace method is called from different thread, InvokeRequired will be true
            if (syncControl.InvokeRequired)
                syncControl.Invoke(new ModifyViewspaceDelegate(ModifyViewspace), new object[] { ViewDesc });
            else
            {
                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (doc.LockDocument())
                {
                    ViewTableRecord vtr = doc.Editor.GetCurrentView();

                    if (!GlobalProperties.ViewPointMode)
                    {
                        RotateView(ViewDesc[0], vtr);
                        if (ViewDesc.Count > 1)
                        {
                            MoveView(ViewDesc[1], vtr);
                        }
                    }
                    else
                        RotateViewDest(ViewDesc, vtr);

                    doc.Editor.SetCurrentView(vtr);
                }
            }
        }



        private void MoveView(Point3D Target, ViewTableRecord vtr)
        {
            if (Target != null)
                vtr.Target = new Point3d(Target.X, Target.Y, Target.Z);
        }

        private void RotateView(Point3D xyzAngles, ViewTableRecord vtr)
        {
            Vector3d current = _initialView.RotateBy(xyzAngles.Y, Vector3d.YAxis);
            current = current.RotateBy(xyzAngles.Z, Vector3d.ZAxis);
            current = current.RotateBy(xyzAngles.X, Vector3d.XAxis);
            vtr.ViewDirection = current;
        }

        private void RotateViewDest(List<Point3D> ViewDesc, ViewTableRecord vtr)
        {
            Point3d view = new Point3d(ViewDesc[0].X, ViewDesc[0].Y, ViewDesc[0].Z);
            Point3d target = new Point3d(ViewDesc[1].X, ViewDesc[1].Y, ViewDesc[1].Z);
            //vtr.Target = new Point3d(0, 0, 0);
            vtr.Target = target; // camera around descriptor       
            Vector3d viewvector = target.GetVectorTo(view);
            //vtr.ViewDirection = viewvector;
            vtr.ViewDirection = vtr.Target.GetVectorTo(new Point3d(1.5*ViewDesc[0].X, 1.5*ViewDesc[0].Y, 1.5*ViewDesc[0].Z));
            //vtr.ViewDirection =  new Vector3d(ViewDesc[0].X, ViewDesc[0].Y, ViewDesc[0].Z);

            vtr.CenterPoint = new Point2d(5*ViewDesc[3].X, -5*ViewDesc[3].Y);
        }

        private ObjectId PreviousViewPoint;

        public void DrawPolylines(List<Point3D> Objects, bool ShouldDeletePrevious, Autodesk.AutoCAD.Colors.Color color)
        {
            // If ModifyViewspace method is called from different thread, InvokeRequired will be true
            if (syncControl.InvokeRequired)
                syncControl.Invoke(new DrawPolylinesDelegate(DrawPolylines), new object[] { Objects, ShouldDeletePrevious, color });
            else
            {
                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (DocumentLock docLock = doc.LockDocument())
                {
                    Database currentDb = doc.Database;
                    using (Transaction trans = currentDb.TransactionManager.StartTransaction())
                    {
                        // Deleting the previous drawn object
                        if ((PreviousViewPoint != ObjectId.Null) && (ShouldDeletePrevious))
                        {
                            Entity ent = (Entity)trans.GetObject(PreviousViewPoint, OpenMode.ForWrite);
                            ent.Erase();
                            ent.Dispose();
                        }
                        // Open the Block table for read
                        BlockTable blockTable;
                        blockTable = trans.GetObject(currentDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                        // Open the Block table record Model space for write
                        BlockTableRecord blockTblRec =
                            trans.GetObject(blockTable[BlockTableRecord.ModelSpace],
                            OpenMode.ForWrite) as BlockTableRecord;

                        Point3dCollection plCollection = new Point3dCollection();
                        foreach (Point3D p in Objects)
                        {
                            plCollection.Add(new Point3d(p.X, p.Y, p.Z));
                        }
                        Polyline3d pl = new Polyline3d(Poly3dType.SimplePoly, plCollection, false);
                        pl.Color = color;

                        PreviousViewPoint = blockTblRec.AppendEntity(pl);
                        trans.AddNewlyCreatedDBObject(pl, true);
                        trans.Commit();
                        
                        // Updates the screen without flickering of view
                        AcadApp.UpdateScreen(); // or doc.Editor.Regen();
                    }
                }
            }
        }

        private List<ObjectId> PreviousCoordinates;

        public void DrawCoordinates(List<List<Point3D>> Objects, bool ShouldDelete)
        {
            // If ModifyViewspace method is called from different thread, InvokeRequired will be true
            if (syncControl.InvokeRequired)
                syncControl.Invoke(new DrawCoordinatesDelegate(DrawCoordinates), new object[] { Objects, ShouldDelete });
            else
            {
                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (DocumentLock docLock = doc.LockDocument())
                {
                    Database currentDb = doc.Database;
                    using (Transaction trans = currentDb.TransactionManager.StartTransaction())
                    {
                        if ((PreviousCoordinates != null) && (ShouldDelete))
                        {
                            foreach (ObjectId item in PreviousCoordinates)
                            {
                                Entity ent = (Entity)trans.GetObject(item, OpenMode.ForWrite);
                                ent.Erase();
                                ent.Dispose();
                            }
                        }
                        // Open the Block table for read
                        BlockTable blockTable;
                        blockTable = trans.GetObject(currentDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                        // Open the Block table record Model space for write
                        BlockTableRecord blockTblRec =
                            trans.GetObject(blockTable[BlockTableRecord.ModelSpace],
                            OpenMode.ForWrite) as BlockTableRecord;

                        Autodesk.AutoCAD.Colors.Color[] colors = new Autodesk.AutoCAD.Colors.Color[3];
                        colors[0] = Autodesk.AutoCAD.Colors.Color.FromRgb(255, 0, 0);
                        colors[1] = Autodesk.AutoCAD.Colors.Color.FromRgb(0, 255, 0);
                        colors[2] = Autodesk.AutoCAD.Colors.Color.FromRgb(0, 0, 255);
                        
                        int colorCounter = 0;
                        PreviousCoordinates = new List<ObjectId>();
                        foreach (List<Point3D> plList in Objects)
                        {
                            Point3dCollection plCollection = new Point3dCollection();
                            foreach (Point3D p in plList)
                            {
                                plCollection.Add(new Point3d(p.X, p.Y, p.Z));
                            }
                            Polyline3d pl = new Polyline3d(Poly3dType.SimplePoly, plCollection, false);
                            pl.Color = colors[colorCounter];
                            colorCounter++;

                            PreviousCoordinates.Add(blockTblRec.AppendEntity(pl));
                            trans.AddNewlyCreatedDBObject(pl, true);
                        }
                        trans.Commit();
                        // Updates the screen without flickering of view
                        //doc.Editor.Regen();
                        Autodesk.AutoCAD.ApplicationServices.Application.UpdateScreen();
                    }
                }
            }
        }
        #endregion
    }

    public class CalcDistanceException : System.ApplicationException
    {
        public CalcDistanceException()
        {
        }

        public CalcDistanceException(string message)
            : base(message)
        {
        }
    } 
}
