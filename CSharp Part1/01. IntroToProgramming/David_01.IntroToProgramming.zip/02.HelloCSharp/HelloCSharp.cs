﻿// Create, compile and run a “Hello C#” console application

using System;

class HelloCSharp
{
    static void Main()
    {
        Console.WriteLine("Hello C#");
    }
}
