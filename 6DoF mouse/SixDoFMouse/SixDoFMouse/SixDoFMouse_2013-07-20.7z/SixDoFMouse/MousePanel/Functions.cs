﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using System.Drawing;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.GraphicsSystem;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CADBest.Geometry;

namespace SixDoFMouse
{
    public static class Functions
    {
        #region Windows functions
        public static float ReadPrefScale()
        {
            RegistryKey sk1 = Registry.CurrentUser.OpenSubKey("Software\\CADBEST\\6DOF Mouse");
            float scale;
            if (sk1 != null)
            {
                scale = (float)Convert.ToDouble(sk1.GetValue("Scale"));
                if (scale == 0)
                    scale = 1;
            }
            else
                scale = 1;
            return scale;
        }

        public static Bitmap ResizeBitmap(float scale, Bitmap source)
        {
            int width, height;
            Bitmap bmp;
            Graphics graph;
            width = (int)(source.Width * scale);
            height = (int)(source.Height * scale);
            bmp = new Bitmap(width, height, source.PixelFormat);
            graph = Graphics.FromImage(bmp);
            graph.DrawImage(source, new Rectangle(0, 0, width, height));
            return bmp;
        }
        #endregion
        #region AutoCAD functions
        public static void MoveView(double x, double y, double z)
        {
            // Get the current document and database
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acCurDb = acDoc.Database;

            // Start a transaction
            using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
            {
                // Get the current view
                using (ViewTableRecord acView = acDoc.Editor.GetCurrentView())
                {
                    //Point3d newTarget = new Point3d(acView.Target.X - x, acView.Target.Y - y, acView.Target.Z - z);
                    Point3d newTarget = new Point3d(x, y, z);
                    acView.Target = newTarget;

                    // Set the current view
                    acDoc.Editor.SetCurrentView(acView);
                }
                // Commit the changes
                acTrans.Commit();
            }
        }

        public static void DrawPolylines(List<Point3D> Objects)
        {
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            using (DocumentLock docLock = acDoc.LockDocument())
            {
                Database acCurDb = acDoc.Database;
                using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
                {
                    // Open the Block table for read
                    BlockTable acBlkTbl;
                    acBlkTbl = acTrans.GetObject(acCurDb.BlockTableId,
                                                       OpenMode.ForRead) as BlockTable;
                    // Open the Block table record Model space for write
                    BlockTableRecord acBlkTblRec;
                    acBlkTblRec = acTrans.GetObject(acBlkTbl[BlockTableRecord.ModelSpace],
                                                          OpenMode.ForWrite) as BlockTableRecord;

                    Polyline3d pl = new Polyline3d();
                    foreach (Point3D p in Objects)
                    {

                    }

                    Line acLine = new Line(start, end);
                    // Add the new object to the block table record and the transaction
                    acBlkTblRec.AppendEntity(acLine);
                    acTrans.AddNewlyCreatedDBObject(acLine, true);
                    // Draw circle around start point
                    Circle circ = new Circle(start, vec, 15);
                    acBlkTblRec.AppendEntity(circ);
                    acTrans.AddNewlyCreatedDBObject(circ, true);
                    // Save the new object to the database
                    acTrans.Commit();
                }
            }
        }

        private static Vector3d InitialView = new Vector3d(0, 0, 0);

        public static void RotateView(List<Point3D> Orientation)
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            ViewTableRecord vtr = doc.Editor.GetCurrentView();

            if ((InitialView.X == 0) && (InitialView.Y == 0) && (InitialView.Z == 0))
            {
                InitialView = vtr.ViewDirection;
            }


            Vector3d current = InitialView.RotateBy(Math.Asin(Orientation[0].X) * -1, Vector3d.ZAxis);
            //Vector3d current = vtr.ViewDirection.RotateBy(Orientation[0].X, Vector3d.ZAxis);
            
            //current = current.RotateBy(Orientation[1].X, Vector3d.YAxis);
            //current = current.RotateBy(Orientation[2].X, Vector3d.ZAxis);
            //vtr.ViewDirection = new Vector3d(Orientation[0].X, Orientation[0].Y, Orientation[0].Z);
            

            //double angle = Math.Asin(Orientation[0].X);

            //vtr.ViewDirection = vtr.ViewDirection.RotateBy(angleMean, Vector3d.ZAxis);
            vtr.ViewDirection = current;
            doc.Editor.SetCurrentView(vtr);

            //.RotateBy(Orientation[0].X, vtr.ViewDirection.GetPerpendicularVector());
            //vtr.ViewTwist += 0.26;

            

        }
        #endregion
    }

    public class CalcDistanceException : System.ApplicationException
    {
        public CalcDistanceException()
        {
        }

        public CalcDistanceException(string message)
            : base(message)
        {
        }
    } 
}
