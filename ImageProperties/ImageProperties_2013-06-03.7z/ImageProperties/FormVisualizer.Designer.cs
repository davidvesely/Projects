﻿namespace ImageProperties
{
    partial class FormVisualizer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.imageBoxEmgu = new Emgu.CV.UI.ImageBox();
            this.zoomPicBox1 = new ImageProperties.ZoomPicBox();
            ((System.ComponentModel.ISupportInitialize)(this.imageBoxEmgu)).BeginInit();
            this.SuspendLayout();
            // 
            // imageBoxEmgu
            // 
            this.imageBoxEmgu.BackColor = System.Drawing.SystemColors.ControlDark;
            this.imageBoxEmgu.Location = new System.Drawing.Point(506, 238);
            this.imageBoxEmgu.Name = "imageBoxEmgu";
            this.imageBoxEmgu.Size = new System.Drawing.Size(164, 226);
            this.imageBoxEmgu.TabIndex = 2;
            this.imageBoxEmgu.TabStop = false;
            // 
            // zoomPicBox1
            // 
            this.zoomPicBox1.AutoScroll = true;
            this.zoomPicBox1.AutoScrollMinSize = new System.Drawing.Size(372, 484);
            this.zoomPicBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.zoomPicBox1.Image = null;
            this.zoomPicBox1.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Default;
            this.zoomPicBox1.Location = new System.Drawing.Point(13, 13);
            this.zoomPicBox1.Name = "zoomPicBox1";
            this.zoomPicBox1.Size = new System.Drawing.Size(372, 484);
            this.zoomPicBox1.TabIndex = 0;
            this.zoomPicBox1.Text = "zoomPicBox1";
            this.zoomPicBox1.Zoom = 1F;
            // 
            // FormVisualizer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 601);
            this.Controls.Add(this.imageBoxEmgu);
            this.Controls.Add(this.zoomPicBox1);
            this.Location = new System.Drawing.Point(10, 10);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormVisualizer";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Formsdasad";
            ((System.ComponentModel.ISupportInitialize)(this.imageBoxEmgu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ZoomPicBox zoomPicBox1;
        private Emgu.CV.UI.ImageBox imageBoxEmgu;

    }
}