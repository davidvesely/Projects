﻿namespace QuickStichNamespace
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonProcess = new System.Windows.Forms.Button();
            this.buttonLoadImages = new System.Windows.Forms.Button();
            this.picBoxSecond = new QuickStichNamespace.ZoomPicBox();
            this.picBoxFirst = new QuickStichNamespace.ZoomPicBox();
            this.SuspendLayout();
            // 
            // buttonProcess
            // 
            this.buttonProcess.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonProcess.Location = new System.Drawing.Point(996, 556);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new System.Drawing.Size(75, 23);
            this.buttonProcess.TabIndex = 2;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new System.EventHandler(this.buttonProcess_Click);
            // 
            // buttonLoadImages
            // 
            this.buttonLoadImages.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonLoadImages.Location = new System.Drawing.Point(915, 556);
            this.buttonLoadImages.Name = "buttonLoadImages";
            this.buttonLoadImages.Size = new System.Drawing.Size(75, 23);
            this.buttonLoadImages.TabIndex = 3;
            this.buttonLoadImages.Text = "Load";
            this.buttonLoadImages.UseVisualStyleBackColor = true;
            this.buttonLoadImages.Click += new System.EventHandler(this.buttonLoadImages_Click);
            // 
            // picBoxSecond
            // 
            this.picBoxSecond.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picBoxSecond.AutoScroll = true;
            this.picBoxSecond.AutoScrollMinSize = new System.Drawing.Size(502, 538);
            this.picBoxSecond.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picBoxSecond.Cursor = System.Windows.Forms.Cursors.Cross;
            this.picBoxSecond.Image = null;
            this.picBoxSecond.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            this.picBoxSecond.Location = new System.Drawing.Point(569, 12);
            this.picBoxSecond.Name = "picBoxSecond";
            this.picBoxSecond.Size = new System.Drawing.Size(502, 538);
            this.picBoxSecond.TabIndex = 1;
            this.picBoxSecond.Text = "zoomPicBox2";
            this.picBoxSecond.Zoom = 1F;
            this.picBoxSecond.Paint += new System.Windows.Forms.PaintEventHandler(this.picBox_Paint);
            this.picBoxSecond.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picBox_MouseClick);
            // 
            // picBoxFirst
            // 
            this.picBoxFirst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picBoxFirst.AutoScroll = true;
            this.picBoxFirst.AutoScrollMinSize = new System.Drawing.Size(529, 537);
            this.picBoxFirst.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picBoxFirst.Cursor = System.Windows.Forms.Cursors.Cross;
            this.picBoxFirst.Image = null;
            this.picBoxFirst.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            this.picBoxFirst.Location = new System.Drawing.Point(13, 13);
            this.picBoxFirst.Name = "picBoxFirst";
            this.picBoxFirst.Size = new System.Drawing.Size(529, 537);
            this.picBoxFirst.TabIndex = 0;
            this.picBoxFirst.Text = "zoomPicBox1";
            this.picBoxFirst.Zoom = 1F;
            this.picBoxFirst.Paint += new System.Windows.Forms.PaintEventHandler(this.picBox_Paint);
            this.picBoxFirst.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picBox_MouseClick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 591);
            this.Controls.Add(this.buttonLoadImages);
            this.Controls.Add(this.buttonProcess);
            this.Controls.Add(this.picBoxSecond);
            this.Controls.Add(this.picBoxFirst);
            this.Name = "FormMain";
            this.Text = "Quick Stitch";
            this.Resize += new System.EventHandler(this.FormMain_Resize);
            this.ResumeLayout(false);

        }

        #endregion

        private ZoomPicBox picBoxFirst;
        private ZoomPicBox picBoxSecond;
        private System.Windows.Forms.Button buttonProcess;
        private System.Windows.Forms.Button buttonLoadImages;
    }
}

