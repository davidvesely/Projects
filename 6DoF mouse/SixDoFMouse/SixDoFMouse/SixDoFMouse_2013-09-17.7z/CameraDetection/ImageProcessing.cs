﻿using CADBest.Geometry;
using SixDoFMouse.CameraDetection;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// ******************************************************************************************** //
//                                        width = cols                                          //
//                                       height = rows                                          //
// ******************************************************************************************** //

namespace SixDoFMouse
{
    public static class ImageProcessing
    {
        public static string OpenImageFile()
        {
            using (OpenFileDialog diag = new OpenFileDialog())
            {
                string strFileName = string.Empty;
                diag.Filter = "bmp files|*.bmp|jpg files (*.jpg)|*.jpg|png files (*.png)|*.png|All files (*.*)|*.*";
                diag.FilterIndex = 1;
                diag.RestoreDirectory = true;
                if (diag.ShowDialog() == DialogResult.OK)
                    strFileName = diag.FileName;
                return strFileName;
            }
        }
        
        public static Color InvertColor(Color c)
        {
            return Color.FromArgb(255 - c.R, 255 - c.G, 255 - c.B);
        }

        public static void ConvertXY(List<List<Point3D>> source, int rows)
        {
            for (int i = 0; i < source.Count; i++)
                ConvertXY(source[i], rows);
        }

        public static void ConvertXY(List<Point3D> source, int rows)
        {
            for (int i = 0; i < source.Count; i++)
                ConvertXY(source[i], rows);
        }

        public static void ConvertXY(Point3D sourceP, int rows)
        {
            sourceP.Y = rows - sourceP.Y;
        }

        private static bool IsBetween(int number, int start, int end)
        {
            if ((start < number) && (number < end))
                return true;
            else
                return false;
        }

        public static Color GetColor(byte[, ,] imgSource, WeightCenter p, int borderPixels)
        {
            int RSum = 0, GSum = 0, BSum = 0;
            int pixelCounter = 0;
            for (int i = p.y - borderPixels; i <= p.y + borderPixels; i++)
            {
                for (int j = p.x - borderPixels; j <= p.x + borderPixels; j++)
                {
                    RSum += imgSource[i, j, 2];
                    GSum += imgSource[i, j, 1];
                    BSum += imgSource[i, j, 0];
                    pixelCounter++;
                }
            }
            byte resultR = (byte)(RSum / pixelCounter);
            byte resultG = (byte)(GSum / pixelCounter);
            byte resultB = (byte)(BSum / pixelCounter);
            return Color.FromArgb(resultR, resultG, resultB);
        }

        private const int MAX_MIN_SUMS = 10;

        //public static SortedSet<PixelData>[] FrameMinMaxPixelSums(byte[,,] imgData)
        //{
        //    SortedSet<PixelData> maxSums = new SortedSet<PixelData>(new PixelDataComparer());
        //    SortedSet<PixelData> minSums = new SortedSet<PixelData>(new PixelDataComparer());
        //    //PixelData firstPixel = new PixelData(imgData[0, 0, 2], imgData[0, 0, 1], imgData[0, 0, 0]);
        //    //maxSums.Add(firstPixel);
        //    //minSums.Add(firstPixel);
        //    maxSums.Add(new PixelData());
        //    minSums.Add(new PixelData(255, 255, 255, 765));

        //    for (int i = 0; i < imgData.GetLength(0); i++)
        //    {
        //        for (int j = 0; j < imgData.GetLength(1); j++)
        //        {
        //            int red = imgData[i, j, 2];
        //            int green = imgData[i, j, 1];
        //            int blue = imgData[i, j, 0];
        //            int currentSum = red + green + blue;

        //            // Max Sums set
        //            if (currentSum > maxSums.Min.Sum)
        //            {
        //                bool isAdded = maxSums.Add(new PixelData(red, green, blue, currentSum));
        //                if (isAdded && (maxSums.Count > MAX_MIN_SUMS))
        //                    maxSums.Remove(maxSums.Min);
        //            }

        //            // Min Sums set
        //            if (currentSum < maxSums.Max.Sum)
        //            {
        //                bool isAdded = minSums.Add(new PixelData(red, green, blue, currentSum));
        //                if (isAdded && (minSums.Count > MAX_MIN_SUMS))
        //                    minSums.Remove(minSums.Max);
        //            }
        //        }
        //    }

        //    return new SortedSet<PixelData>[] { maxSums, minSums };
        //}

        public static Color ModifyColor(Color aRGB)
        {
            byte R1 = aRGB.R, G1 = aRGB.G, B1 = aRGB.B;
            int min1 = Geometry.Min(R1, G1, B1);
            byte R2 = (byte)(R1 - min1);
            byte G2 = (byte)(G1 - min1);
            byte B2 = (byte)(B1 - min1);

            byte max1 = Geometry.Max(R2, G2, B2);
            double k1 = 255d / max1;

            byte R3 = (byte)Math.Round(R2 * k1);
            byte G3 = (byte)Math.Round(G2 * k1);
            byte B3 = (byte)Math.Round(B2 * k1);

            return Color.FromArgb(R3, G3, B3);
        }

        public static void AdaptiveColorFiltration(byte[,,] dataSource, 
            byte[,,] dataContainer, Color baseColor, FilterColors channel, int dMax)
        {
            Color C3 = baseColor;
            for (int i = 0; i < dataSource.GetLength(0); i++) // Rows
            {
                for (int j = 0; j < dataSource.GetLength(1); j++) // Cols
                {
                    byte R = dataSource[i, j, 2];
                    byte G = dataSource[i, j, 1];
                    byte B = dataSource[i, j, 0];

                    Color Cf = ModifyColor(Color.FromArgb(R, G, B));
                    dataSource[i, j, 2] = Cf.R;
                    dataSource[i, j, 1] = Cf.G;
                    dataSource[i, j, 0] = Cf.B;
                    
                    double d = 
                        Math.Pow(C3.R - Cf.R, 2) +
                        Math.Pow(C3.G - Cf.G, 2) +
                        Math.Pow(C3.B - Cf.B, 2);

                    if (d > dMax)
                        dataContainer[i, j, 2] = dataContainer[i, j, 1] = dataContainer[i, j, 0] = 0;
                    else
                    {
                        dataContainer[i, j, 2] = 255;
                        dataContainer[i, j, 1] = dataContainer[i, j, 0] = 0;
                    }
                }
            }
        }

        //private static readonly
        //    int[,] filterMatrix =
        //    new int[,] { { 1, 2, 1 }, 
        //                 { 2, 4, 2 },
        //                 { 1, 2, 1 } };

        public static void Filter3x3(byte[, ,] dataSource, byte[,,] dataDestination)
        {
            int rows = dataSource.GetLength(0);
            int cols = dataSource.GetLength(1);
            for (int i = 0; i < rows; i++) // Rows
            {
                for (int j = 0; j < cols; j++) // Cols
                {
                    int RSum = 0, GSum = 0, BSum = 0;
                    int prevRow = -1, prevCol = -1, nextRow = 1, nextCol = 1;
                    int pixelCounter = 0;

                    if (i == 0)
                        prevRow = 0;
                    else if (i == (rows - 1))
                        nextRow = 0;
                    if (j == 0)
                        prevCol = 0;
                    else if (j == (cols - 1))
                        nextCol = 0;

                    for (int wi = prevRow; wi <= nextRow; wi++) // Rows
                    {
                        for (int ri = prevCol; ri <= nextCol; ri++) // Cols
                        {
                            RSum += dataSource[i + wi, j + ri, (int)FilterColors.R];
                            GSum += dataSource[i + wi, j + ri, (int)FilterColors.G];
                            BSum += dataSource[i + wi, j + ri, (int)FilterColors.B];
                            pixelCounter++;
                        } // End ri
                    } // End wi

                    dataDestination[i, j, (int)FilterColors.R] = (byte)(RSum / pixelCounter);
                    dataDestination[i, j, (int)FilterColors.G] = (byte)(GSum / pixelCounter);
                    dataDestination[i, j, (int)FilterColors.B] = (byte)(BSum / pixelCounter);
                } // End j
            } // End i
        } // End method
    } // End class
} // End namespace
