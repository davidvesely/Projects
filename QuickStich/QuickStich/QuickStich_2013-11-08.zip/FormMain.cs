﻿using CADBest.GeometryNamespace;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace QuickStichNamespace
{
    public partial class FormMain : Form
    {
        private QuickStitch StitchModule;
        private Pen PointsPen = new Pen(Color.Red);
        private const int PointVisualizeRadius = 10;

        public FormMain()
        {
            InitializeComponent();
            ResizePictureBoxes();
        }

        private void buttonLoadImages_Click(object sender, EventArgs e)
        {
            LoadImages(picBoxFirst);
            LoadImages(picBoxSecond);
            StitchModule = new QuickStitch(picBoxFirst.Image, picBoxSecond.Image);
        }

        private string OpenImageFile()
        {
            using (OpenFileDialog diag = new OpenFileDialog())
            {
                string strFileName = string.Empty;
                diag.Filter = "bmp files|*.bmp|jpg files (*.jpg)|*.jpg|png files (*.png)|*.png|All files (*.*)|*.*";
                diag.FilterIndex = 4;
                diag.RestoreDirectory = true;
                if (diag.ShowDialog() == DialogResult.OK)
                    strFileName = diag.FileName;
                return strFileName;
            }
        }

        private void LoadImages(ZoomPicBox pictureContainer)
        {
            string fileName = OpenImageFile();
            if (!string.IsNullOrEmpty(fileName))
            {
                pictureContainer.LoadImage(fileName);
            }
        }

        private void ResizePictureBoxes()
        {
            int spaceBetweenPictures = 20;
            int margin = 13;
            int bottomSpace = 45;

            // Width and height
            int width = this.ClientRectangle.Width / 2 - margin - spaceBetweenPictures / 2;
            int height = this.ClientRectangle.Height - margin - bottomSpace;
            picBoxFirst.Size = new Size(width, height);
            picBoxSecond.Size = new Size(width, height);

            // Location of second picture box (first is not moved)
            picBoxSecond.Left = picBoxFirst.Right + spaceBetweenPictures;
        }

        private void picBox_Paint(object sender, PaintEventArgs e)
        {
            if (StitchModule == null)
                return;
            ZoomPicBox picBox = sender as ZoomPicBox;
            if (picBox == null)
                return;

            List<Point3D> points;
            switch (picBox.Name)
            {
                case "picBoxFirst":
                    points = StitchModule.FirstPoints;
                    break;
                case "picBoxSecond":
                    points = StitchModule.SecondPoints;
                    break;
                default:
                    points = null;
                    break;
            }

            foreach (Point3D p in points)
            {
                // Draw circle at every clicked spot in the image
                // with center at the clicked spot, and radius set
                // by the constant
                e.Graphics.DrawEllipse(
                    PointsPen, 
                    (float)(p.X - PointVisualizeRadius / 2f),
                    (float)(p.Y - PointVisualizeRadius / 2f),
                    PointVisualizeRadius,
                    PointVisualizeRadius);
               
            }
        }

        private void picBox_MouseClick(object sender, MouseEventArgs e)
        {
            if (StitchModule == null)
                return;

            ZoomPicBox picBox = sender as ZoomPicBox;
            if ((picBox == null) || (picBox.Image == null))// ||  (e.Button != MouseButtons.Left))
                return;

            List<Point3D> points;
            switch (picBox.Name)
            {
                case "picBoxFirst":
                    points = StitchModule.FirstPoints;
                    break;
                case "picBoxSecond":
                    points = StitchModule.SecondPoints;
                    break;
                default:
                    points = null;
                    break;
            }

            // Left mouse button - add points
            if (e.Button == MouseButtons.Left)
            {
                if ((points != null) && (points.Count < 4))
                {
                    points.Add(new Point3D(picBox.CurrentState.OriginalX,
                        picBox.CurrentState.OriginalY, 0));
                }
            }

            // Right mouse button - remove points
            if ((e.Button == MouseButtons.Right) &&
                (points != null) && (points.Count != 0))
            {
                points.RemoveAt(points.Count - 1);                
            }

            picBox.Refresh();

        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            StitchModule.TransformPictures();
        }

        private void FormMain_Resize(object sender, EventArgs e)
        {
            ResizePictureBoxes();
        }
    }
}
