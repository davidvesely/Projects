﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProperties
{
    public partial class Form1Visualizer : Form
    {
        public Form1Visualizer()
        {
            InitializeComponent();
        }

        public void SetPicture(Bitmap img)
        {
            zoomPicBox1.Width = img.Width;
            zoomPicBox1.Height = img.Height;
            zoomPicBox1.Image = img;
            ResizePicture();
        }

        protected override void OnResize(EventArgs e)
        {
            ResizePicture();
        }

        void ResizePicture()
        {
            zoomPicBox1.Width = this.ClientRectangle.Width - 26;
            zoomPicBox1.Height = this.ClientRectangle.Height - 26;
            //zoomPicBox1.UpdateDisplayedImage();
        }
    }
}
