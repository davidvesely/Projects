﻿using Emgu.CV;
using Emgu.CV.Features2D;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using CADBest.Geometry;
using SixDoFMouse.CameraDetection;

namespace SixDoFMouse
{
    public partial class FormWebCamEmgu : Form
    {
        #region Members and Constants
        private Capture _capture = null;
        private bool _captureInProgress;
        public bool IsCapturing
        {
            get { return _captureInProgress; }
        }

        private FormVisualizer vizRed, vizGreen, vizBlue, vizFilters, vizOriginal, vizYellow, vizDataText;
        private FormChart chartPoint;

        private Image<Bgr, byte> _frame;
        private Image<Bgr, byte> imgOriginal;
        private Image<Bgr, byte> imgFiltered;
        private FilteringCoeficients Coef;

        Image<Bgr, byte> imgB;
        Image<Bgr, byte> imgG;
        Image<Bgr, byte> imgR;
        Image<Bgr, byte> imgY;

        int FrameRows, FrameCols; // Rows and cols of current resolution

        MouseDataContainer dataMouse;
        public Calibration calibrateModule;
        MovingAveraging crawlAveragingModule;
        MouseRecognition MouseRecognitionModule;

        // Storage for n-count camera ViewPoints divided in 4 lists
        //private List<List<Point3D>> ArrViewPoint;

        // This is the center of a frame (Width / 2 and Height / 2),
        // intersection of X axis with right side of the frame (e.g. the right middle point)
        // and top middle point, the intersection of Y axis with the top edge
        // Its used for 4-point calibration algorithm, and is initialized every time when capturing starts
        List<Point3D> CenterProjXY;

        // There will be stored previous orientation of mouse
        private List<Point3D> FrameSinCos;

        public TimerDispatchParameters TimerDispatch;

        // Usage of different colors and visualizers
        private bool USE_RED = true;
        private bool USE_GREEN = true;
        private bool USE_BLUE = true;
        private bool USE_YELLOW = true;
        private bool SHOW_FILTERS = false;

        public event CameraDrawViewPointHandler DrawViewPoint;
        public event CameraDrawViewPointHandler DrawCoordinateSystem;
        public event CameraSendOrientationHandler SendOrientationParameters;
        #endregion

        public FormWebCamEmgu()
        {
            InitializeComponent();

            MouseRecognitionModule = new MouseRecognition();
            if (USE_RED)
                vizRed = new FormVisualizer(FormVisualizer.DisplayMode.Emgu, "Red");
            if (USE_GREEN)
                vizGreen = new FormVisualizer(FormVisualizer.DisplayMode.Emgu, "Green");
            if (USE_BLUE)
                vizBlue = new FormVisualizer(FormVisualizer.DisplayMode.Emgu, "Blue");
            if (USE_YELLOW)
                vizYellow = new FormVisualizer(FormVisualizer.DisplayMode.Emgu, "Yellow");
            if (SHOW_FILTERS)
                vizFilters = new FormVisualizer(FormVisualizer.DisplayMode.Emgu, "Filtered");
            vizOriginal = new FormVisualizer(FormVisualizer.DisplayMode.Emgu, "Original");
            vizDataText = new FormVisualizer(FormVisualizer.DisplayMode.Text, "Text Data");

            // For testing purposes
            MouseRecognitionModule.mainTextViz = vizDataText;

            dataMouse = MouseDataContainer.Instance;
            calibrateModule = new Calibration();
            crawlAveragingModule = new MovingAveraging();
            TimerDispatch = new TimerDispatchParameters(10);
            TimerDispatch.TickMethod += timerDispatchParameters_TickMethod;
            ReadRegistryValues();
        }

        private void Initialize()
        {
            GetCoefficients();

            CenterProjXY = new List<Point3D>(3);
            CenterProjXY.Add(new Point3D(FrameCols / 2, FrameRows / 2, 0)); // Center of projection
            CenterProjXY.Add(new Point3D(FrameCols, FrameRows / 2, 0)); // X axis middle
            CenterProjXY.Add(new Point3D(FrameCols / 2, FrameRows, 0)); // Y axis middle

            _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_FRAME_WIDTH, FrameCols);
            _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_FRAME_HEIGHT, FrameRows);
            _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_EXPOSURE, trackBarBrightness.Value);
            imgB = new Image<Bgr, byte>(FrameCols, FrameRows);
            imgG = new Image<Bgr, byte>(FrameCols, FrameRows);
            imgR = new Image<Bgr, byte>(FrameCols, FrameRows);
            imgY = new Image<Bgr, byte>(FrameCols, FrameRows);
        }

        private void SaveScreenshots()
        {
            if (USE_RED)
                imgR.Save("WebcamRed.bmp");
            if (USE_GREEN)
                imgG.Save("WebcamGreen.bmp");
            if (USE_BLUE)
                imgB.Save("WebcamBlue.bmp");
            if (USE_YELLOW)
                imgY.Save("WebcamYellow.bmp");
            _frame.Save("WebcamOriginal.bmp");
            MessageBox.Show("Screenshots are taken successfully!");
        }

        private void GetCoefficients()
        {
            Coef.IM_R_K = trbR_K.Value;
            Coef.IM_R_ADD = (int)trbR_Add.Value;
            Coef.IM_R_PRAG = (int)trbR_Prag.Value;
            
            Coef.IM_G_K = trbG_K.Value;
            Coef.IM_G_ADD = (int)trbG_Add.Value;
            Coef.IM_G_PRAG = (int)trbG_Prag.Value;
            
            Coef.IM_B_K = trbB_K.Value;
            Coef.IM_B_ADD = (int)trbB_Add.Value;
            Coef.IM_B_PRAG = (int)trbB_Prag.Value;
            
            Coef.IM_Y_K = trbY_K.Value;
            Coef.IM_Y_ADD = (int)trbY_Add.Value;
            Coef.IM_Y_PRAG = (int)trbY_Prag.Value;

            int width, height;
            if (!int.TryParse(textBoxWidth.Text, out width) ||
                !int.TryParse(textBoxHeight.Text, out height))
                return;

            FrameRows = height;
            FrameCols = width;
        }

        private void RGBFilter()
        {
            double im;
            byte min;
            byte red, new_red;
            byte green, new_green;
            byte blue, new_blue;

            byte[, ,] data1 = imgR.Data;
            byte[, ,] data2 = imgG.Data;
            byte[, ,] data3 = imgB.Data;
            byte[, ,] dataYellow = imgY.Data;
            byte[, ,] dataFiltered = imgFiltered.Data;

            for (int i = imgFiltered.Rows - 1; i >= 0; i--)
            {
                for (int j = imgFiltered.Cols - 1; j >= 0; j--)
                {
                    red = dataFiltered[i, j, 2];
                    green = dataFiltered[i, j, 1];
                    blue = dataFiltered[i, j, 0];

                    // Subtract the Min of R G B colors from the remaining two
                    min = red;
                    if (min > green)
                        min = green;
                    if (min > blue)
                        min = blue;
                    red = (byte)(red - min);
                    green = (byte)(green - min);
                    blue = (byte)(blue - min);

                    dataFiltered[i, j, 2] = red;
                    dataFiltered[i, j, 1] = green;
                    dataFiltered[i, j, 0] = blue;

                    if (USE_RED)
                    {
                        if (checkBox1.Checked)
                        {
                            im = red * Coef.IM_R_K - green - blue + Coef.IM_R_ADD;
                            if (im >= Coef.IM_R_PRAG)
                                new_red = 255;
                            else
                                new_red = 0;
                        }
                        else
                            new_red = red;
                        data1[i, j, 2] = new_red;
                        data1[i, j, 1] = 0;
                        data1[i, j, 0] = 0;
                    }

                    if (USE_GREEN)
                    {
                        if (checkBox1.Checked)
                        {
                            im = green * Coef.IM_G_K - red - blue + Coef.IM_G_ADD;
                            if (im >= Coef.IM_G_PRAG)
                                new_green = 255;
                            else
                                new_green = 0;
                        }
                        else
                            new_green = green;
                        data2[i, j, 2] = 0;
                        data2[i, j, 1] = new_green;
                        data2[i, j, 0] = 0;
                    }

                    if (USE_BLUE)
                    {
                        if (checkBox1.Checked)
                        {
                            im = blue * Coef.IM_B_K - green - red + Coef.IM_B_ADD;
                            if (im >= Coef.IM_B_PRAG)
                                new_blue = 255;
                            else
                                new_blue = 0;
                        }
                        else
                            new_blue = blue;
                        data3[i, j, 2] = 0;
                        data3[i, j, 1] = 0;
                        data3[i, j, 0] = new_blue;
                    }

                    if (USE_YELLOW)
                    {
                        if (checkBox1.Checked)
                        {
                            im = Coef.IM_Y_K * (0.8 * red + green) - 2 * blue + Coef.IM_Y_ADD;
                            if (im >= Coef.IM_Y_PRAG)
                            {
                                new_red = 255;
                                new_green = 255;
                            }
                            else
                            {
                                new_red = 0;
                                new_green = 0;
                            }
                        }
                        else
                        {
                            new_red = red;
                            new_green = green;
                        }
                        dataYellow[i, j, 2] = new_red;
                        dataYellow[i, j, 1] = new_green;
                        dataYellow[i, j, 0] = 0;
                    }
                }
            }
        }

        /// <summary>
        /// Average list of points and sent result to AutoCAD
        /// </summary>
        /// <param name="ViewPointRed">Four points estimated by Red side</param>
        /// <param name="ViewPointGreen">Four points estimated by Green side</param>
        /// <param name="ViewPointBlue">Four points estimated by Blue side</param>
        /// <param name="ViewPointYellow">Four points estimated by Yellow side</param>
        public List<Point3D> AverageViewPoint(List<Point3D> ViewPointRed, List<Point3D> ViewPointGreen, List<Point3D> ViewPointBlue, List<Point3D> ViewPointYellow)           
        {
            List<Point3D> ViewPointAverage = new List<Point3D>();
            int n = 4;
            double x = 0, y = 0, z = 0; //, sumRed, sumGreen, sumBlue, sumYellow, sumAverage; // xRed, xGreen, xBlue, xYellow, yRed, yGreen, yBlue, yYellow, zRed, zGreen, zBlue, zYellow;
            //sumRed = 0;
            //sumGreen = 0;
            //sumBlue = 0;
            //sumYellow = 0;

            //TO DO TOMORROW
            //if (ViewPointRed != null)
            //    sumRed = Math.Abs(ViewPointRed[0].X) + Math.Abs(ViewPointRed[0].Y) + Math.Abs(ViewPointRed[0].Z);
            //if (ViewPointGreen != null)
            //    sumGreen = Math.Abs(ViewPointGreen[0].X) + Math.Abs(ViewPointGreen[0].Y) + Math.Abs(ViewPointGreen[0].Z);
            //if (ViewPointBlue != null)
            //    sumBlue = Math.Abs(ViewPointBlue[0].X) + Math.Abs(ViewPointBlue[0].Y) + Math.Abs(ViewPointBlue[0].Z);
            //if (ViewPointYellow != null)
            //    sumYellow = Math.Abs(ViewPointYellow[0].X) + Math.Abs(ViewPointYellow[0].Y) + Math.Abs(ViewPointYellow[0].Z);

            //sumAverage = (sumRed + sumGreen + sumBlue + sumYellow) / 4;



            if (ViewPointRed == null)
            {
                n--;
                ViewPointRed = new List<Point3D>(4);
                ViewPointRed.Add(new Point3D(0, 0, 0));
                ViewPointRed.Add(new Point3D(0, 0, 0));
                ViewPointRed.Add(new Point3D(0, 0, 0));
                ViewPointRed.Add(new Point3D(0, 0, 0));
            }

            if (ViewPointGreen == null)
            {
                n--;
                ViewPointGreen = new List<Point3D>(4);
                ViewPointGreen.Add(new Point3D(0, 0, 0));
                ViewPointGreen.Add(new Point3D(0, 0, 0));
                ViewPointGreen.Add(new Point3D(0, 0, 0));
                ViewPointGreen.Add(new Point3D(0, 0, 0));
            }

            if (ViewPointBlue == null)
            {
                n--;
                ViewPointBlue = new List<Point3D>(4);
                ViewPointBlue.Add(new Point3D(0, 0, 0));
                ViewPointBlue.Add(new Point3D(0, 0, 0));
                ViewPointBlue.Add(new Point3D(0, 0, 0));
                ViewPointBlue.Add(new Point3D(0, 0, 0));
            }

            if (ViewPointYellow == null)
            {
                n--;
                ViewPointYellow = new List<Point3D>(4);
                ViewPointYellow.Add(new Point3D(0, 0, 0));
                ViewPointYellow.Add(new Point3D(0, 0, 0));
                ViewPointYellow.Add(new Point3D(0, 0, 0));
                ViewPointYellow.Add(new Point3D(0, 0, 0));
            }

            //vizDataText.SetText(n.ToString());
            //if (n == 2)
            //    MessageBox.Show("Test = 2");
            //if (n == 3)
            //{
            //    MessageBox.Show("Test = 3"); 
            //}
            //if (n == 4)
            //{
            //    MessageBox.Show("Test == 4");
            //}

            for (int i = 0; i < 4; i++)
            {
                if (n != 0)
                {
                    x = (ViewPointRed[i].X + ViewPointGreen[i].X + ViewPointBlue[i].X + ViewPointYellow[i].X) / n;  //+ ViewPointYellow[i].X
                    y = (ViewPointRed[i].Y + ViewPointGreen[i].Y + ViewPointBlue[i].Y + ViewPointYellow[i].Y) / n;  //+ ViewPointYellow[i].Y
                    z = (ViewPointRed[i].Z + ViewPointGreen[i].Z + ViewPointBlue[i].Z + ViewPointYellow[i].Z) / n;  //+ ViewPointYellow[i].Z
                    ViewPointAverage.Add(new Point3D(x, y, z));
                }
            }

            if (n != 0)
                return ViewPointAverage;
            else
                return null;
        }

        private void timerDispatchParameters_TickMethod(object sender, EventArgs e)
        {
            if (crawlAveragingModule.Middle0 != null)
            {
                List<Point3D> ViewPoint = new List<Point3D>(4);
                ViewPoint.Add(crawlAveragingModule.Middle0);
                ViewPoint.Add(crawlAveragingModule.Middle1);
                ViewPoint.Add(crawlAveragingModule.Middle2);
                ViewPoint.Add(crawlAveragingModule.Middle3);
                SendControlParameters(ViewPoint, imgOriginal.Data);
            }

            VisualizeImageData(false);
        }

        private void VisualizeImageData(bool PreventFlick)
        {
            if ((USE_RED) && (!PreventFlick))
                vizRed.SetPicture(imgR);
            if (USE_GREEN)
                vizGreen.SetPicture(imgG);
            if (USE_BLUE)
                vizBlue.SetPicture(imgB);
            if (USE_YELLOW)
                vizYellow.SetPicture(imgY);
            if (SHOW_FILTERS)
                vizFilters.SetPicture(imgFiltered);

            // Prevent from drawing a frame when ViewPoint is not obtained
            // and descriptor should be projected without flickering
            //if (PreventFlick)
            //    return;
            //imgOriginal = imgOriginal.Flip(Emgu.CV.CvEnum.FLIP.HORIZONTAL);
            vizOriginal.SetPicture(imgOriginal);
        }

        private void ProcessFrame(object sender, EventArgs arg)
        {
            _frame = _capture.RetrieveBgrFrame();
            //_frame = _capture.RetrieveBgrFrame().Flip(Emgu.CV.CvEnum.FLIP.NONE);
            //_frame = _capture.RetrieveBgrFrame().Flip(Emgu.CV.CvEnum.FLIP.HORIZONTAL);
            //_frame = _capture.RetrieveBgrFrame().Flip(Emgu.CV.CvEnum.FLIP.VERTICAL);

            imgOriginal = _frame.Convert<Bgr, byte>();
            imgFiltered = _frame.Convert<Bgr, byte>();

            MouseRecognitionModule.imgVisualizePoints = imgOriginal;

            //test min max pixel sums
            //SortedSet<PixelData>[] maxMinSets = ImageProcessing.FrameMinMaxPixelSums(imgOriginal.Data);
            //vizDataText.SetText("Max sum = " + maxMinSets[0].Max.Sum.ToString(), "Min sum = " + maxMinSets[1].Min.Sum.ToString());

            RGBFilter();
            //int n = 0;
            List<Point3D> ViewPointYellow = null;// = new List<Point3D>();
            List<Point3D> ViewPointRed = null;// = new List<Point3D>();
            List<Point3D> ViewPointBlue = null;// = new List<Point3D>();
            List<Point3D> ViewPointGreen = null;// = new List<Point3D>();

            if (USE_RED)
            {
                ViewPointRed = MouseRecognitionModule.Detection(imgR, imgOriginal.Data, FilterColors.Red, FrameRows, FrameCols, CenterProjXY);
                //if (ViewPointRed != null)
                //{
                    //SendControlParameters(ViewPointRed, imgOriginal.Data);
                //}
            }

            if (USE_BLUE)
            {
                ViewPointBlue = MouseRecognitionModule.Detection(imgB, imgOriginal.Data, FilterColors.Blue, FrameRows, FrameCols, CenterProjXY);
                //if (ViewPointBlue != null)
                //    SendControlParameters(ViewPointBlue, imgOriginal.Data);
            }

            if (USE_GREEN)
            {

                ViewPointGreen = MouseRecognitionModule.Detection(imgG, imgOriginal.Data, FilterColors.Green, FrameRows, FrameCols, CenterProjXY);
                //if (ViewPointGreen != null)
                //    SendControlParameters(ViewPointGreen, imgOriginal.Data);
            }

            if (USE_YELLOW)
            {

                ViewPointYellow = MouseRecognitionModule.Detection(imgY, imgOriginal.Data, FilterColors.Yellow, FrameRows, FrameCols, CenterProjXY);
                //if (ViewPointYellow != null)
                //    SendControlParameters(ViewPointYellow, imgOriginal.Data);
            }

            List<Point3D> averagedVP = AverageViewPoint(ViewPointRed, ViewPointGreen, ViewPointBlue, ViewPointYellow);

            if (averagedVP != null)
            {
                if (TimerDispatch.Enabled)
                    crawlAveragingModule.CrawlingAveraging(averagedVP);
                else
                {
                    SendControlParameters(averagedVP, imgOriginal.Data);
                }
            }

            bool PreventFlick = checkBoxTopFlickering.Checked && (averagedVP == null);
            VisualizeImageData(PreventFlick);
        }

        #region WebCam and UI
        public void ResetCapturing()
        {
            if (_captureInProgress)
            {  //stop the capture
                buttonCapture.Text = "Start Capture";
                _capture.Pause();
                _capture.ImageGrabbed -= ProcessFrame;
            }
            else
            {
                //start the capture
                buttonCapture.Text = "Stop";
                try
                {
                    int choice;
                    if (radioButton1.Checked)
                        choice = 0;
                    else
                        choice = 1;
                    _capture = new Capture(choice);
                    _capture.ImageGrabbed += ProcessFrame;
                }
                catch (NullReferenceException excpt)
                {
                    MessageBox.Show(excpt.Message);
                }
                Initialize();
                _capture.Start();

                if (USE_RED)
                    vizRed.Show();
                if (USE_GREEN)
                    vizGreen.Show();
                if (USE_BLUE)
                    vizBlue.Show();
                if (USE_YELLOW)
                    vizYellow.Show();
                if (SHOW_FILTERS)
                    vizFilters.Show();
                vizOriginal.Show();
            }
            //TimerDispatch.Enabled = !TimerDispatch.Enabled;
            _captureInProgress = !_captureInProgress;
        }

        private void ReleaseData()
        {
            if (_capture != null)
                _capture.Dispose();
        }

        private void FormWebCamEmgu_FormClosing(object sender, FormClosingEventArgs e)
        {
            WriteRegistryValues();
            ReleaseData();

            if (USE_RED)
                vizRed.Close();
            if (USE_GREEN)
                vizGreen.Close();
            if (USE_BLUE)
                vizBlue.Close();
            if (USE_YELLOW)
                vizYellow.Close();
            if (SHOW_FILTERS)
                vizFilters.Close();
            vizOriginal.Close();
            if (!vizDataText.IsDisposed)
                vizDataText.Close();
            crawlAveragingModule.stopwatch.Enabled = false;
            checkBoxCharts.Checked = false;
        }

        private void trackBarBrightness_Scroll(object sender, EventArgs e)
        {
            bool continueCapture = false;
            if (_captureInProgress)
            {
                ResetCapturing(); // Stop the capture
                continueCapture = true;
            }
            _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_BRIGHTNESS, trackBarBrightness.Value);
            labelBrightness.Text = "Brightness: " + trackBarBrightness.Value;
            if (continueCapture)
                ResetCapturing();
        }

        private void ReadRegistryValues()
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\" + this.ProductName);
                if ((rk != null) && ((string)rk.GetValue("R_K", "-1") != "-1"))
                {
                    trbR_K.Value = Convert.ToDouble((string)rk.GetValue("R_K"));
                    trbG_K.Value = Convert.ToDouble((string)rk.GetValue("G_K"));
                    trbB_K.Value = Convert.ToDouble((string)rk.GetValue("B_K"));
                    trbY_K.Value = Convert.ToDouble((string)rk.GetValue("Y_K"));

                    trbR_Add.Value = Convert.ToDouble((string)rk.GetValue("R_Add"));
                    trbG_Add.Value = Convert.ToDouble((string)rk.GetValue("G_Add"));
                    trbB_Add.Value = Convert.ToDouble((string)rk.GetValue("B_Add"));
                    trbY_Add.Value = Convert.ToDouble((string)rk.GetValue("Y_Add"));

                    trbR_Prag.Value = Convert.ToDouble((string)rk.GetValue("R_Prag"));
                    trbG_Prag.Value = Convert.ToDouble((string)rk.GetValue("G_Prag"));
                    trbB_Prag.Value = Convert.ToDouble((string)rk.GetValue("B_Prag"));
                    trbY_Prag.Value = Convert.ToDouble((string)rk.GetValue("Y_Prag"));

                    textBoxWidth.Text = (string)rk.GetValue("CaptureWidth");
                    textBoxHeight.Text = (string)rk.GetValue("CaptureHeight");

                    //Main Window
                    this.Top = Convert.ToInt32((string)rk.GetValue("MainTop"));
                    this.Left = Convert.ToInt32((string)rk.GetValue("MainLeft"));
                    this.Width = Convert.ToInt32((string)rk.GetValue("MainWidth"));
                    this.Height = Convert.ToInt32((string)rk.GetValue("MainHeight"));
                    if (vizRed != null)
                    {
                        //Red Window
                        vizRed.Top = Convert.ToInt32((string)rk.GetValue("RedTop"));
                        vizRed.Left = Convert.ToInt32((string)rk.GetValue("RedLeft"));
                        vizRed.Width = Convert.ToInt32((string)rk.GetValue("RedWidth"));
                        vizRed.Height = Convert.ToInt32((string)rk.GetValue("RedHeight"));
                        //string redZoom = (string)rk.GetValue("RedZoom");
                        //vizRed.imageBoxEmgu.SetZoomScale(Convert.ToDouble(redZoom), new Point(0, 0));
                    }
                    if (vizGreen != null)
                    {
                        //Green Window
                        vizGreen.Top = Convert.ToInt32((string)rk.GetValue("GreenTop"));
                        vizGreen.Left = Convert.ToInt32((string)rk.GetValue("GreenLeft"));
                        vizGreen.Width = Convert.ToInt32((string)rk.GetValue("GreenWidth"));
                        vizGreen.Height = Convert.ToInt32((string)rk.GetValue("GreenHeight"));
                    }
                    if (vizBlue != null)
                    {
                        //Blue Window
                        vizBlue.Top = Convert.ToInt32((string)rk.GetValue("BlueTop"));
                        vizBlue.Left = Convert.ToInt32((string)rk.GetValue("BlueLeft"));
                        vizBlue.Width = Convert.ToInt32((string)rk.GetValue("BlueWidth"));
                        vizBlue.Height = Convert.ToInt32((string)rk.GetValue("BlueHeight"));
                    }
                    if (vizFilters != null)
                    {
                        //Filters Window
                        vizFilters.Top = Convert.ToInt32((string)rk.GetValue("FiltersTop"));
                        vizFilters.Left = Convert.ToInt32((string)rk.GetValue("FiltersLeft"));
                        vizFilters.Width = Convert.ToInt32((string)rk.GetValue("FiltersWidth"));
                        vizFilters.Height = Convert.ToInt32((string)rk.GetValue("FiltersHeight"));
                    }
                    if (vizOriginal != null)
                    {
                        //Original Window
                        vizOriginal.Top = Convert.ToInt32((string)rk.GetValue("OriginalTop"));
                        vizOriginal.Left = Convert.ToInt32((string)rk.GetValue("OriginalLeft"));
                        vizOriginal.Width = Convert.ToInt32((string)rk.GetValue("OriginalWidth"));
                        vizOriginal.Height = Convert.ToInt32((string)rk.GetValue("OriginalHeight"));
                    }
                    if (vizYellow != null)
                    {
                        //Yellow Window
                        vizYellow.Top = Convert.ToInt32((string)rk.GetValue("YellowTop"));
                        vizYellow.Left = Convert.ToInt32((string)rk.GetValue("YellowLeft"));
                        vizYellow.Width = Convert.ToInt32((string)rk.GetValue("YellowWidth"));
                        vizYellow.Height = Convert.ToInt32((string)rk.GetValue("YellowHeight"));
                    }
                    // Brightness
                    trackBarBrightness.Value = (int)rk.GetValue("Brightness");
                    labelBrightness.Text = "Brightness " + trackBarBrightness.Value.ToString();

                    calibrateModule.ReadRegistryCalibration(rk);
                }
            }
            catch (Exception)
            {
            }
            finally
            {
                if (rk != null)
                    rk.Dispose();
            }
        }

        private void WriteRegistryValues()
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.LocalMachine.CreateSubKey("SOFTWARE\\" + this.ProductName);
                rk.SetValue("R_K", trbR_K.Value);
                rk.SetValue("G_K", trbG_K.Value);
                rk.SetValue("B_K", trbB_K.Value);
                rk.SetValue("Y_K", trbY_K.Value);

                rk.SetValue("R_Add", trbR_Add.Value);
                rk.SetValue("G_Add", trbG_Add.Value);
                rk.SetValue("B_Add", trbB_Add.Value);
                rk.SetValue("Y_Add", trbY_Add.Value);

                rk.SetValue("R_Prag", trbR_Prag.Value);
                rk.SetValue("G_Prag", trbG_Prag.Value);
                rk.SetValue("B_Prag", trbB_Prag.Value);
                rk.SetValue("Y_Prag", trbY_Prag.Value);

                rk.SetValue("CaptureWidth", textBoxWidth.Text);
                rk.SetValue("CaptureHeight", textBoxHeight.Text);

                //Main Window
                rk.SetValue("MainTop", this.Top.ToString());
                rk.SetValue("MainLeft", this.Left.ToString());
                rk.SetValue("MainWidth", this.Width.ToString());
                rk.SetValue("MainHeight", this.Height.ToString());
                if (vizRed != null)
                {
                    //Red Window
                    rk.SetValue("RedTop", vizRed.Top.ToString());
                    rk.SetValue("RedLeft", vizRed.Left.ToString());
                    rk.SetValue("RedWidth", vizRed.Width.ToString());
                    rk.SetValue("RedHeight", vizRed.Height.ToString());
                    rk.SetValue("RedZoom", vizRed.imageBoxEmgu.ZoomScale.ToString());
                }
                if (vizGreen != null)
                {
                    //Green Window
                    rk.SetValue("GreenTop", vizGreen.Top.ToString());
                    rk.SetValue("GreenLeft", vizGreen.Left.ToString());
                    rk.SetValue("GreenWidth", vizGreen.Width.ToString());
                    rk.SetValue("GreenHeight", vizGreen.Height.ToString());
                    rk.SetValue("GreenZoom", vizGreen.imageBoxEmgu.ZoomScale.ToString());
                }
                if (vizBlue != null)
                {
                    //Blue Window
                    rk.SetValue("BlueTop", vizBlue.Top.ToString());
                    rk.SetValue("BlueLeft", vizBlue.Left.ToString());
                    rk.SetValue("BlueWidth", vizBlue.Width.ToString());
                    rk.SetValue("BlueHeight", vizBlue.Height.ToString());
                    rk.SetValue("BlueZoom", vizBlue.imageBoxEmgu.ZoomScale.ToString());
                }
                if (vizFilters != null)
                {
                    //Filters Window
                    rk.SetValue("FiltersTop", vizFilters.Top.ToString());
                    rk.SetValue("FiltersLeft", vizFilters.Left.ToString());
                    rk.SetValue("FiltersWidth", vizFilters.Width.ToString());
                    rk.SetValue("FiltersHeight", vizFilters.Height.ToString());
                    rk.SetValue("FiltersZoom", vizFilters.imageBoxEmgu.ZoomScale.ToString());
                }
                if (vizOriginal != null)
                {
                    //Original Window
                    rk.SetValue("OriginalTop", vizOriginal.Top.ToString());
                    rk.SetValue("OriginalLeft", vizOriginal.Left.ToString());
                    rk.SetValue("OriginalWidth", vizOriginal.Width.ToString());
                    rk.SetValue("OriginalHeight", vizOriginal.Height.ToString());
                    rk.SetValue("OriginalZoom", vizOriginal.imageBoxEmgu.ZoomScale.ToString());
                }
                if (vizYellow != null)
                {
                    //Yellow Window
                    rk.SetValue("YellowTop", vizYellow.Top.ToString());
                    rk.SetValue("YellowLeft", vizYellow.Left.ToString());
                    rk.SetValue("YellowWidth", vizYellow.Width.ToString());
                    rk.SetValue("YellowHeight", vizYellow.Height.ToString());
                    rk.SetValue("YellowZoom", vizYellow.imageBoxEmgu.ZoomScale.ToString());
                }
                // Brightness
                rk.SetValue("Brightness", trackBarBrightness.Value);
                calibrateModule.WriteRegistryCalibration(rk);
            }
            catch (Exception)
            {
                MessageBox.Show("Error during writing settings in registry!");
            }
            finally
            {
                if (rk != null)
                    rk.Dispose();
            }
        }
        #endregion

        List<Point3D> CalibrationCopy = new List<Point3D>();
        List<Point3D> currentClone = new List<Point3D>();     

        Point3D ySinCosCurr = null;
        Point3D zSinCosCurr = null;
        Point3D xSinCosCurr = null;
        Point3D TranslationCurr = null;        

        Point3D[] DestParamCalibration = null;        
        Point3D[] currParam = null;

        private void SendControlParameters(List<Point3D> ViewPoint, byte[, ,] ImgDataToFlash)
        {
            List<Point3D> ViewDescriptor = new List<Point3D>();
            if (GlobalProperties.ViewPointMode)
            {
                ViewDescriptor.Add(ViewPoint[0]);
                ViewDescriptor.Add(ViewPoint[1]);
                ViewDescriptor.Add(ViewPoint[2]);
            }

            Visualization.ProjectDescriptor(ViewPoint, CenterProjXY, imgR, FrameRows);
            List<Point3D> currentOrientation = calibrateModule.RecalcOrientation(ViewPoint);          
   
            if (GlobalProperties.ViewPointMode)
            {
                if (checkBoxPan.Checked)
                    ViewDescriptor.Add(currentOrientation[0].Clone());
                else
                    ViewDescriptor.Add(new Point3D(0, 0, 0));

                ViewDescriptor.Add(currentOrientation[1]);
                ViewDescriptor.Add(currentOrientation[2]);
                ViewDescriptor.Add(currentOrientation[3]);
            }

            if (calibrateModule.p0translation != null)
            {         
                //Move current frame with translation of calibration frame 
                Geometry.p_add(currentOrientation, calibrateModule.p0translation, -1);

                //Rotation of whole current coordinate system with parameters of calibration
                Geometry.p_rotY(currentOrientation, calibrateModule.ySinCosAxis, -1);
                Geometry.p_rotZ(currentOrientation, calibrateModule.zSinCosAxis, -1);
                Geometry.p_rotX(currentOrientation, calibrateModule.xSinCosAxis, -1);

                //Move back current frame with translation of calibration frame 
                Geometry.p_add(currentOrientation, calibrateModule.p0translation, 1);
                CalibrationCopy = Geometry.CloneList(calibrateModule.CalibrationOrientation[0]);                                            

                //Move calibration to origin and calculate align parameters
                Geometry.p_add(CalibrationCopy, CalibrationCopy[0].Clone(), -1);
                DestParamCalibration = Geometry.align_calc_pars(
                CalibrationCopy[0],
                CalibrationCopy[1],
                CalibrationCopy[2]);

                //Move current frame to origin and calculate align parameters
                TranslationCurr = currentOrientation[0].Clone();
                Geometry.p_add(currentOrientation, currentOrientation[0].Clone(), -1);
                currParam = Geometry.align_calc_pars(
                    currentOrientation[0],
                    currentOrientation[1],
                    currentOrientation[2]);
               
                //Rotate Current frame coordinate system to coincide with XYZ
                ySinCosCurr = Geometry.calc_rotY(currentOrientation[1]);
                Geometry.p_rotY(currentOrientation, ySinCosCurr, -1);

                zSinCosCurr = Geometry.calc_rotZ(currentOrientation[1]);
                Geometry.p_rotZ(currentOrientation, zSinCosCurr, -1);

                xSinCosCurr = Geometry.calc_rotX(currentOrientation[2]);
                Geometry.p_rotX(currentOrientation, xSinCosCurr, -1);                           

                //Align current orientation with parameters of calibration and current frame parameters before rotation
                Geometry.align(currentOrientation, currParam, DestParamCalibration);

                //Translate back with current frame translation
                Geometry.p_add(currentOrientation, TranslationCurr.Clone(), 1);

                if ((DrawCoordinateSystem != null) && (!checkBoxTestRot.Checked))
                {
                    List<List<Point3D>> obejctsForDraw = new List<List<Point3D>>();
                    obejctsForDraw.Add(new List<Point3D>(
                        new Point3D[] { currentOrientation[0], currentOrientation[1] }));
                    obejctsForDraw.Add(new List<Point3D>(
                        new Point3D[] { currentOrientation[0], currentOrientation[2] }));
                    obejctsForDraw.Add(new List<Point3D>(
                        new Point3D[] { currentOrientation[0], currentOrientation[3] }));
                    DrawCoordinateSystem(this, new DrawViewPointEventArgs(obejctsForDraw, true));
                }           

            }           
      
            // Call subscribers to SendOrientationParameters event
            if ((SendOrientationParameters != null) && (checkBoxSendControlPars.Checked))
            {
                SendOrientationEventArgs orientationArgs =
                    new SendOrientationEventArgs();

                if (!GlobalProperties.ViewPointMode)
                {
                    List<Point3D> rotationAngles =
                        MouseRecognition.GetRotationAngles(currentOrientation);
                    // Calculate the corresponding angles for X, Y and Z rotation
                    double xRot = Math.Asin(rotationAngles[0].X);
                    double yRot = Math.Asin(rotationAngles[1].X);
                    double zRot = Math.Asin(rotationAngles[2].X);
                    orientationArgs.OrientationParameters.Add(new Point3D(xRot, yRot, zRot));
                }
                else
                    orientationArgs.OrientationParameters = ViewDescriptor;

                if (SendOrientationParameters != null)
                    SendOrientationParameters(this, orientationArgs);
            }

            if (calibrateModule.IsCalibrate)
            {
                calibrateModule.CalcCalibration(ViewPoint, ImgDataToFlash);
                //if (calibrateModule.DrawTest != null)
                //    ;
            }

            if ((checkBoxCharts.Checked) && (!chartPoint.IsDisposed))
            {
            //    chartPt1.UpdateChart(ViewPoint[1].X, ViewPoint[1].Y, ViewPoint[1].Z);
            //    chartPtD1.UpdateChart(dArr1.X, dArr1.Y, dArr1.Z);
            }

            // Call subscribers for this event
            if (checkBoxDrawViewPoint.Checked && (DrawViewPoint != null))
                DrawViewPoint(this, new DrawViewPointEventArgs(ViewPoint, true));
        }

        private void buttonCalibrateCenter_Click(object sender, EventArgs e)
        {
            // Start a calibration
            calibrateModule.IsCalibrate = true;

            //calibrateModule.CalibrationCalcParameters();
        }

        private void checkBoxCharts_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxCharts.Checked)
            {
                chartPoint = new FormChart(30, -500, 500, "Point 1", ChartUpdatingMode.Timed, 500);
                chartPoint.AddCurve("X Axis");
                chartPoint.AddCurve("Y Axis");
                chartPoint.AddCurve("Z Axis");
                chartPoint.Show();
            }
            else
            {
                chartPoint.Close();
            }
        }

        private void checkBoxShowTextViz_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowTextViz.Checked)
            {
                if (vizDataText.IsDisposed)
                    vizDataText = new FormVisualizer(FormVisualizer.DisplayMode.Text, "Text display");
                vizDataText.Show();
            }
            else
                vizDataText.Close();
        }

        private void checkBoxDrawViewPoint_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}