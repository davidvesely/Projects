﻿using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SixDoFMouse.CameraDetection
{
    public partial class FormStaticFrame : Form
    {
        Image<Bgr, byte> imageCopy;
        Color BaseColor = Color.Empty;

        public FormStaticFrame()
        {
            InitializeComponent();
        }

        public void SetPicture(string fileName)
        {
            zoomPicBox1.LoadImage(fileName);
            imageCopy = new Image<Bgr, byte>(fileName);
        }

        private void zoomPicBox1_MouseClick(object sender, MouseEventArgs e)
        {
            // GroupBox1
            double x = double.Parse(zoomPicBox1.CurrentState.GetX());
            double y = double.Parse(zoomPicBox1.CurrentState.GetY());
            labelX.Text = zoomPicBox1.CurrentState.GetX();
            labelY.Text = zoomPicBox1.CurrentState.GetY();
            labelR.Text = zoomPicBox1.CurrentState.GetR();
            labelG.Text = zoomPicBox1.CurrentState.GetG();
            labelB.Text = zoomPicBox1.CurrentState.GetB();
            labelZoom.Text = zoomPicBox1.GetCurrentZoom().ToString();
            groupBoxPixelInfo.Refresh();

            if (BaseColor == Color.Empty)
            {
                BaseColor = ImageProcessing.GetColor(
                    imageCopy.Data, new WeightCenter((int)x, (int)y, 0), 1);
                BaseColor = ImageProcessing.ModifyColor(BaseColor);
                labelRBase.Text = BaseColor.R.ToString();
                labelGBase.Text = BaseColor.G.ToString();
                labelBBase.Text = BaseColor.B.ToString();
                groupBoxBase.Refresh();
            }
            else
            {
                Color color = ImageProcessing.GetColor(
                    imageCopy.Data, new WeightCenter((int)x, (int)y, 0), 0);
                color = ImageProcessing.ModifyColor(color);
                double d = Math.Pow(BaseColor.R - color.R, 2) +
                           Math.Pow(BaseColor.G - color.G, 2) +
                           Math.Pow(BaseColor.B - color.B, 2);
                labelRCurrent.Text = color.R.ToString();
                labelGCurrent.Text = color.G.ToString();
                labelBCurrent.Text = color.B.ToString();
                labelD.Text = d.ToString();
                groupBoxFiltration.Refresh();
            }
        }
    }
}
