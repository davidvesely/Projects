﻿// Create a console application that calculates
// and prints the square of the number 12345

using System;

class Square12345
{
    static void Main()
    {
        int number = 12345;
        int numberSquare = number * number;
        Console.WriteLine("Square of 12345 is " + numberSquare);
    }
}
