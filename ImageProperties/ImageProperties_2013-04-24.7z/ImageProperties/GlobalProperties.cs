﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageProperties
{
    class GlobalProperties
    {
        public static float[] zoomFactor = { 0.01f, 0.03f, 0.05f, 0.08f, 0.09f, .1f, .2f, .3f, .4f, .5f, .7f, .8f, 
                                       1f, 1.5f, 2f, 2.5f, 3f, 3.5f, 4f, 5f, 6f, 8f, 
                                       10f, 12f, 15f, 20f, 35f, 40f, 45f, 50f, 55f, 60f };
    }
}
