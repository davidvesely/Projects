﻿using CADBest.GeometryNamespace;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace QuickStichNamespace
{
    public class QuickStitch
    {
        #region Global Members
        public List<Point3D> FirstPoints, SecondPoints, SourcePars, DestPars;        
        List<Point3D> FirstBmpFrame = new List<Point3D>();
        List<Point3D> SecondBmpFrame = new List<Point3D>();
        public Bitmap FirstBMP, SecondBMP;

        #endregion

        public QuickStitch(Bitmap FirstBMPMain, Bitmap SecondBMPMain)
        {
            FirstPoints = new List<Point3D>();
            SecondPoints = new List<Point3D>();
            FirstBMP = FirstBMPMain;
            SecondBMP = SecondBMPMain;

            // First frame coordinate
            FirstBmpFrame.Add(new Point3D(0, 0, 0));
            FirstBmpFrame.Add(new Point3D(0, FirstBMP.Height, 0));
            FirstBmpFrame.Add(new Point3D(FirstBMP.Width, FirstBMP.Height, 0)); // Width is X. Height is Y.
            FirstBmpFrame.Add(new Point3D(FirstBMP.Width, 0, 0));   
            //Second frame coordinate
            SecondBmpFrame.Add(new Point3D(0, 0, 0));
            SecondBmpFrame.Add(new Point3D(0, SecondBMP.Height, 0));
            SecondBmpFrame.Add(new Point3D(SecondBMP.Width, SecondBMP.Height, 0)); // Width is X. Height is Y.
            SecondBmpFrame.Add(new Point3D(SecondBMP.Width, 0, 0));         

        }

        public void TransformPictures()
        {
            if ((FirstPoints.Count != 4) || (SecondPoints.Count != 4))
                return;

            //Step 1. Homography second bmp frame with parameters of selected points.
            SourcePars = Geometry.homography_calc_pars(SecondPoints);
            DestPars = Geometry.homography_calc_pars(FirstPoints);     
            List<Point3D> SecondFrameHomography = Geometry.homography_calc(SecondBmpFrame, SourcePars, DestPars); //The frame will be distorted.
             
            //Step 2
            //Create new frame around distorted old frame. It will be used for creating new bmp.
            List<Point3D> SecondNewRetangle = PolygonToRectangle(SecondFrameHomography);
            //Translate new frame to origin of coordinate system
            Point3D Translation = SecondNewRetangle[0].Clone();
            Geometry.p_add(SecondNewRetangle, Translation, -1);
            Geometry.p_add(SecondFrameHomography, Translation, -1);

            //Create new BMP from new frame.
            int width = (int)Math.Ceiling(SecondNewRetangle[2].X);
            int height = (int)Math.Ceiling(SecondNewRetangle[2].Y);
            Bitmap SecondNewBmp = new Bitmap(width, height);

            //Convert pixel to CadBest Points3D.
            List<List<Point3D>> SecondBMPList = BmpToList(SecondNewBmp);

            //Step 3. Homography back new bmp to first picture. Distorted frame to regular frame of first bmp.
            SourcePars = Geometry.homography_calc_pars(SecondFrameHomography);
            DestPars = Geometry.homography_calc_pars(FirstBmpFrame);
            List<List<Point3D>> HomographySecondToFirst = new List<List<Point3D>>();
            foreach (List<Point3D> curr in SecondBMPList)
            {
                HomographySecondToFirst.Add(Geometry.homography_calc(curr, SourcePars, DestPars));
            }

            //Recalculate new color of the pixel.
            LockBitmap SecondBmpLock = new LockBitmap(SecondBMP);
            SecondBmpLock.LockBits();
            LockBitmap SecondBmpResultLock = new LockBitmap(SecondNewBmp);
            SecondBmpResultLock.LockBits();

            int widthSecondOriginal = FirstBMP.Width;
            int heightSecondOriginal = FirstBMP.Height;
            for (int j = 0; j < HomographySecondToFirst.Count - 2; j++)
            {
                for (int i = 0; i < HomographySecondToFirst[j].Count - 2; i++)
                {
                    //Surrounded pixel from Points
                    List<Point3D> currList = new List<Point3D>();
                    currList.Add(HomographySecondToFirst[j][i]);
                    currList.Add(HomographySecondToFirst[j][i + 1]);
                    currList.Add(HomographySecondToFirst[j + 1][i + 1]);
                    currList.Add(HomographySecondToFirst[j + 1][i]);

                    Color c;
                    if (CompareTwoRetangle(currList, widthSecondOriginal, heightSecondOriginal))
                        c = Color.White;
                    else
                        c = RemapPixels.RecalcPixelColor(currList, SecondBmpLock);

                    SecondBmpResultLock.SetPixel(i, j, c);
                }
            }

            SecondBmpLock.UnlockBits();
            SecondBmpResultLock.UnlockBits();

            #region draw
            //using (Graphics g = Graphics.FromImage(BMPresultTwo))
            //{
            //    Pen linePen = new Pen(Color.Black, 1);
            //    SolidBrush background = new SolidBrush(Color.White);
            //    g.FillRectangle(background, 0, 0, BMPresultTwo.Width, BMPresultTwo.Height);
            //    for (int i = 0; i < PointResultOne.Count - 2; i++)
            //    {
            //        g.DrawLine(linePen, PointResultOne[i].ToPointNET(), PointResultOne[i + 1].ToPointNET());
            //        //g.DrawLine(linePen, FourCorners[i].ToPointNET(), FourCorners[i + 1].ToPointNET());
                    
            //    }
            //    g.DrawLine(linePen, PointResultOne[0].ToPointNET(), PointResultOne[PointResultOne.Count - 1].ToPointNET());
            //    //g.DrawLine(linePen, FourCorners[0].ToPointNET(), FourCorners[FourCorners.Count - 1].ToPointNET());
            //}
            #endregion

            FormResult res = new FormResult();
            res.SetImage(SecondNewBmp);
            res.Show();              

        }

        /// <summary>
        /// Create rectangle around four point polygon. 
        /// </summary>
        /// <param name="FourPoints">Four points of polygon. Contra clock-wise order</param>
        /// <returns>List of Point3D</returns>
        public List<Point3D> PolygonToRectangle(List<Point3D> FourPoints)
        {
            double RightX = RemapPixels.Max4(FourPoints[0].X, FourPoints[1].X, FourPoints[2].X ,FourPoints[3].X);
            double LeftX = RemapPixels.Min4(FourPoints[0].X, FourPoints[1].X, FourPoints[2].X, FourPoints[3].X);
            double UpY = RemapPixels.Min4(FourPoints[0].Y, FourPoints[1].Y, FourPoints[2].Y, FourPoints[3].Y);
            double DownY = RemapPixels.Max4(FourPoints[0].Y, FourPoints[1].Y, FourPoints[2].Y, FourPoints[3].Y);

            List<Point3D> result = new List<Point3D>();
            result.Add(new Point3D(LeftX, UpY, 0));
            result.Add(new Point3D(LeftX, DownY, 0));
            result.Add(new Point3D(RightX, DownY, 0));
            result.Add(new Point3D(RightX, UpY, 0));

            return result;
        }

        public bool CompareTwoRetangle(List<Point3D> FourPoints, int width, int height)
        {
            double RightX = RemapPixels.Max4(FourPoints[0].X, FourPoints[1].X, FourPoints[2].X, FourPoints[3].X);
            double LeftX = RemapPixels.Min4(FourPoints[0].X, FourPoints[1].X, FourPoints[2].X, FourPoints[3].X);
            double UpY = RemapPixels.Min4(FourPoints[0].Y, FourPoints[1].Y, FourPoints[2].Y, FourPoints[3].Y);
            double DownY = RemapPixels.Max4(FourPoints[0].Y, FourPoints[1].Y, FourPoints[2].Y, FourPoints[3].Y);

            if ((LeftX < 0) || (RightX > width) || (UpY < 0) || (DownY > height))
                return true;
            else
                return false;
        }

        /// <summary>
        /// Convert Bmp to List of Points3D.  Lists number is height(rows) of bmp. Every list size is wight of bmp(cols).
        /// </summary>
        /// <param name="bmp">Bitmap image</param>
        /// <returns>List of list of Point3D</returns>
        public List<List<Point3D>> BmpToList(Bitmap bmp)
        {
            List<List<Point3D>> result = new List<List<Point3D>>();
            // Fill the array with points, which refers to
            // each pixel corner (e.g. width = 300px,
            // fill the array with 301 pixel corners, same for height)
            for (int i = 0; i < bmp.Height + 1; i++) //Y rows
            {
                List<Point3D> curr = new List<Point3D>(SecondBMP.Width);
                for (int j = 0; j < bmp.Width + 1; j++)// X cols
                {
                    curr.Add(new Point3D(j, i, 0));// i=rows, j=cols
                }
                result.Add(curr);
            }
            return result;
        }
    }
}
