﻿using CADBest.Geometry;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SixDoFMouse
{
    public class GlobalProperties
    {
        public static float[] zoomFactor = { 0.01f, 0.03f, 0.05f, 0.08f, 0.09f, .1f, .2f, .3f, .4f, .5f, .7f, .8f, 
                                       1f, 1.5f, 2f, 2.5f, 3f, 3.5f, 4f, 5f, 6f, 8f, 
                                       10f, 12f, 15f, 20f, 35f, 40f, 45f, 50f, 55f, 60f };

        public static readonly bool ViewPointMode = false;
        // Process Objects or ViewSpace
        public static readonly bool ProcessObjects = true;
        public static readonly bool UseTimers = false;
    }

    public delegate void CameraEventHandler(object sender, EventArgs e);
    public delegate void CameraDrawViewPointHandler(object sender, DrawViewPointEventArgs e);
    public delegate void CameraSendOrientationHandler(object sender, SendOrientationEventArgs e);

    public class DrawViewPointEventArgs : EventArgs
    {
        public List<Point3D> ViewPoint;
        public List<List<Point3D>> CoordinateSystem;
        public bool ShouldDeletePrevious;
        public Autodesk.AutoCAD.Colors.Color Color;

        public DrawViewPointEventArgs(List<Point3D> list, bool ShouldDelete, Autodesk.AutoCAD.Colors.Color color)
            : base()
        {
            ViewPoint = list;
            ShouldDeletePrevious = ShouldDelete;
            Color = color;
        }

        public DrawViewPointEventArgs(List<Point3D> list, bool ShouldDelete)
            : this(list, ShouldDelete, Autodesk.AutoCAD.Colors.Color.FromRgb(255, 255, 255))
        {
        }

        public DrawViewPointEventArgs(List<List<Point3D>> list, bool ShouldDelete)
            : base()
        {
            CoordinateSystem = list;
            ShouldDeletePrevious = ShouldDelete;
        }
    }

    public class SendOrientationEventArgs : EventArgs
    {
        // This list should contain two Point3D objects
        // The first represent the three rotation angles
        // Second is the translation
        public List<Point3D> OrientationParameters;

        public SendOrientationEventArgs()
            : this(new List<Point3D>())
        {
        }

        public SendOrientationEventArgs(List<Point3D> list)
            : base()
        {
            OrientationParameters = list;
        }
    }
}
