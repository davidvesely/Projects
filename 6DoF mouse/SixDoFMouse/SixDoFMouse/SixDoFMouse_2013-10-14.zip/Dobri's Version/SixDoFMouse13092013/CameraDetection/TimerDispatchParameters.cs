﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace SixDoFMouse.CameraDetection
{
    public class TimerDispatchParameters
    {
        private Timer timer;

        public event StopwatchCallEventHandler TickMethod;

        protected virtual void OnTick(EventArgs e)
        {
            if (TickMethod != null)
                TickMethod(this, EventArgs.Empty);
        }

        public TimerDispatchParameters(double interval)
        {
            timer = new Timer(interval);
            timer.Elapsed += new ElapsedEventHandler(this.Stopwatch_Tick);
            timer.AutoReset = true;
        }

        public TimerDispatchParameters() : this(10)
        {
        }

        public bool Enabled
        {
            get { return timer.Enabled; }
            set { timer.Enabled = value; }
        }

        private void Stopwatch_Tick(object sender, ElapsedEventArgs e)
        {
            OnTick(EventArgs.Empty);
        }
    }
}