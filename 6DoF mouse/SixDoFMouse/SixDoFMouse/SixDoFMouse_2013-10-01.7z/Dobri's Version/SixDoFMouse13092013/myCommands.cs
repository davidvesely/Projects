﻿using System;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;
using CADBest.Geometry;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using System.Collections.Generic;
using System.Windows;

[assembly: CommandClass(typeof(SixDoFMouse.MyCommands))]

namespace SixDoFMouse
{
    public class MyCommands
    {
        [CommandMethod("PANEL6DOF", CommandFlags.Modal)]
        public void MyCommand()
        {
            FormControls form = new FormControls();
            form.Show();
        }

        [CommandMethod("TEST_VIEWDIR", CommandFlags.Modal)]
        public void TestViewDir()
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            using (doc.LockDocument())
            {
                ViewTableRecord vtr = doc.Editor.GetCurrentView();
                //   X = -371.5187     Y = 179.3608     Z = 68.3790          0
                //   X = 1128.2365     Y = -558.8058     Z = -56.1291        1
                //   X = 953.5780     Y = -917.8164     Z = -31.5155         2

                Point3d ORIENT2 = new Point3d(953.5780, -917.8164, -31.5155);
                Point3d Targetview = new Point3d(1128.2365, -558.8058, -56.1291);
                vtr.Target = Targetview;
                vtr.ViewDirection = vtr.Target.GetVectorTo(new Point3d(-371.5187, 179.3608, 68.3790));
                vtr.CenterPoint = new Point2d(0, 0);                            
                
                doc.Editor.SetCurrentView(vtr);
            }
        }


    }
}