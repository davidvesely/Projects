﻿// Create a console application that prints the current date and time

using System;

class CurrentDateTime
{
    static void Main()
    {
        Console.Write("Current date and time are: ");
        Console.WriteLine(DateTime.Now);
    }
}
