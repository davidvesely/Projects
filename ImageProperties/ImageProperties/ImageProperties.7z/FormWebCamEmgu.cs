﻿using Emgu.CV;
using Emgu.CV.Features2D;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProperties
{
    public partial class FormWebCamEmgu : Form
    {
        private Capture _capture = null;
        private bool _captureInProgress;
        private FastDetector fastDetect = null;

        private Image<Bgr, Byte> _frame;

        public FormWebCamEmgu()
        {
            InitializeComponent();
            try
            {
                _capture = new Capture(0);
                
                _capture.ImageGrabbed += ProcessFrame;
            }
            catch (NullReferenceException excpt)
            {
                MessageBox.Show(excpt.Message);
            }
        }

        private void ProcessFrame(object sender, EventArgs arg)
        {
            _frame = _capture.RetrieveBgrFrame();//.Flip(Emgu.CV.CvEnum.FLIP.HORIZONTAL);

            //Image<Gray, Byte> grayFrame = _frame.Convert<Gray, Byte>().PyrDown().PyrUp();
            //Image<Gray, Byte> smallGrayFrame = grayFrame.PyrDown();
            //Image<Gray, Byte> smoothedGrayFrame = smallGrayFrame.PyrUp();
            //MKeyPoint[] keyPoints = fastDetect.DetectKeyPoints(grayFrame, null);
            //Image<Bgr, Byte> image = _frame.Clone();
            //foreach (MKeyPoint keypt in keyPoints)
            //{
            //    PointF pt = keypt.Point;
            //    image.Draw(new CircleF(pt, 2), new Bgr(0, 0, 255), 2);
            //}

            //imageBox1.Image = image;

            RGBFilter();
            //keyPoints = fastDetect.DetectKeyPoints(imgR, null);
            //foreach (MKeyPoint keypt in keyPoints)
            //{
            //    PointF pt = keypt.Point;
            //    imgR.Draw(new CircleF(pt, 2), new Gray(128), 2);
            //}
            imageBoxR.Image = imgR;
            imageBoxG.Image = imgG;
            imageBoxB.Image = imgB;
            //imageBoxB.Image = imgGray;
        }

        private void FormWebCamEmgu_Load(object sender, EventArgs e)
        {
            //Read coefficients from registry
            ReadRegistryValues();
        }

        double IM1_R = 1, IM1_G = 1, IM1_B = 1;
        double IM2_G = 1, IM2_R = 1, IM2_B = 1;
        double IM3_B = 1, IM3_R = 1, IM3_G = 1;
        int IM_R_PRAG = 512, IM_R_ADD = 512;
        int IM_G_PRAG = 512, IM_G_ADD = 512;
        int IM_B_PRAG = 512, IM_B_ADD = 512;

        Image<Bgr, Byte> imgB;
        Image<Bgr, Byte> imgG;
        Image<Bgr, Byte> imgR;

        private void GetCoefficients()
        {
            IM1_R = trbR_K.Value;
            IM_R_ADD = (int)trbR_Add.Value;
            IM_R_PRAG = (int)trbR_Prag.Value;

            IM2_G = trbG_K.Value;
            IM_G_ADD = (int)trbG_Add.Value;
            IM_G_PRAG = (int)trbG_Prag.Value;

            IM3_B = trbB_K.Value;
            IM_B_ADD = (int)trbB_Add.Value;
            IM_B_PRAG = (int)trbB_Prag.Value;
        }

        private void RGBFilter()
        {
            double im;
            byte r1, g1, b1;
            byte min;
            byte red, last_red, new_red;
            byte green, last_green, new_green;
            byte blue, new_blue, last_blue;
            float k1;
            // Clone frame(imgOriginal is unmanaged memory)
            Image<Bgr, Byte> cloneOriginal;
            cloneOriginal = _frame.Convert<Bgr, Byte>();

            byte[,,] data1 = imgR.Data;
            byte[,,] data2 = imgG.Data;
            byte[,,] data3 = imgB.Data;
            byte[,,] data = cloneOriginal.Data;

            GetCoefficients();

            for (int i = cloneOriginal.Rows - 1; i >= 0; i--)
            {
                for (int j = cloneOriginal.Cols - 1; j >= 0; j--)
                {
                    red = data[i, j, 2]; //Read to the Red Spectrum
                    green = data[i, j, 1]; //Read to the Green Spectrum
                    blue = data[i, j, 0]; //Read to the BlueSpectrum


                    min = red;
                    if (min > green)
                        min = green;
                    if (min > blue)
                        min = blue;
                    red = (byte)(red - min);
                    green = (byte)(green - min);
                    blue = (byte)(blue - min);


                    k1 = 384f / (float)(red + green + blue + 10);
                    red = (byte)(k1 * red);
                    green = (byte)(green * k1);
                    blue = (byte)(blue * k1);

                    

                    data[i, j, 2] = red; //Read to the Red Spectrum
                    data[i, j, 1] = green; //Read to the Green Spectrum
                    data[i, j, 0] = blue; //Read to the BlueSpectrum
                    

                    im = red * IM1_R - green * IM1_G - blue * IM1_B + IM_R_ADD;
                    if (im >= IM_R_PRAG)
                        new_red = 255;
                    else
                        new_red = 0;
                    data1[i, j, 2] = red;
                    data1[i, j, 1] = 0;
                    data1[i, j, 0] = 0;

                    im = green * IM2_G - red * IM2_R - blue * IM2_B + IM_G_ADD;
                    if (im >= IM_G_PRAG)
                        new_green = 255;
                    else
                        new_green = 0;
                    data2[i, j, 2] = 0;
                    data2[i, j, 1] = new_green;
                    data2[i, j, 0] = 0;

                    im = blue * IM3_B - green * IM3_G - red * IM3_R + IM_B_ADD;
                    if (im >= IM_B_PRAG)
                        new_blue = 255;
                    else
                        new_blue = 0;
                    data3[i, j, 2] = new_red;
                    data3[i, j, 1] = new_green;
                    data3[i, j, 0] = new_blue;

                    //if ((i == 600) && (j == 500))
                    //    MessageBox.Show("Test");

                    //data1[i, j, 2] = (byte)((255 + red - green - blue) / 2); //Red
                    //data1[i, j, 1] = data1[i, j, 0] = 0;

                    //data2[i, j, 1] = (byte)((255 + green - red - blue) / 2); //Green
                    //data2[i, j, 2] = data2[i, j, 0] = 0;

                    //data3[i, j, 0] = (byte)((255 + blue - green - red) / 2); //Blue
                    //data3[i, j, 2] = data3[i, j, 1] = 0;
                }
            }
            imageBox1.Image = cloneOriginal;
        }

        private void buttonCapture_Click(object sender, EventArgs e)
        {
            FormWebCamEmguResult disp1 = new FormWebCamEmguResult();
            disp1.Show();
            if (_capture != null)
            {
                if (_captureInProgress)
                {  //stop the capture
                    buttonCapture.Text = "Start Capture";
                    _capture.Pause();
                }
                else
                {
                    int width, height;
                    //start the capture
                    buttonCapture.Text = "Stop";
                    if (textBoxTreshold.Text != "")
                        fastDetect = new FastDetector(Convert.ToInt32(textBoxTreshold.Text), true);
                    else
                        fastDetect = new FastDetector(20, true);
                    width = Convert.ToInt32(textBoxWidth.Text);
                    height = Convert.ToInt32(textBoxHeight.Text);
                    _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_FRAME_WIDTH, width);
                    _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_FRAME_HEIGHT, height);
                    imgB = new Image<Bgr, Byte>(width, height);
                    imgG = new Image<Bgr, Byte>(width, height);
                    imgR = new Image<Bgr, Byte>(width, height);
                    _capture.Start();
                }

                _captureInProgress = !_captureInProgress;
            }
        }

        private void ReleaseData()
        {
            if (_capture != null)
                _capture.Dispose();
        }

        private void FormWebCamEmgu_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Writing coefficients to memory
            WriteRegistryValues();

            ReleaseData();
            Application.Exit();
        }

        private void ReadRegistryValues()
        {
            try
            {
                using (RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\" + Application.ProductName))
                if (rk != null)
                {
                    
                    string Red_K = (string)rk.GetValue("R_K");
                    if (Red_K != null)
                    {
                        trbR_K.Value = Convert.ToDouble(Red_K);
                        trbG_K.Value = Convert.ToDouble((string)rk.GetValue("G_K"));
                        trbB_K.Value = Convert.ToDouble((string)rk.GetValue("B_K"));

                        trbR_Add.Value = Convert.ToDouble((string)rk.GetValue("R_Add"));
                        trbG_Add.Value = Convert.ToDouble((string)rk.GetValue("G_Add"));
                        trbB_Add.Value = Convert.ToDouble((string)rk.GetValue("B_Add"));

                        trbR_Prag.Value = Convert.ToDouble((string)rk.GetValue("R_Prag"));
                        trbG_Prag.Value = Convert.ToDouble((string)rk.GetValue("G_Prag"));
                        trbB_Prag.Value = Convert.ToDouble((string)rk.GetValue("B_Prag"));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void WriteRegistryValues()
        {
            try
            {
                using (RegistryKey rk = Registry.LocalMachine.CreateSubKey("SOFTWARE\\" + Application.ProductName))
                {
                    rk.SetValue("R_K", trbR_K.Value);
                    rk.SetValue("G_K", trbG_K.Value);
                    rk.SetValue("B_K", trbB_K.Value);

                    rk.SetValue("R_Add", trbR_Add.Value);
                    rk.SetValue("G_Add", trbG_Add.Value);
                    rk.SetValue("B_Add", trbB_Add.Value);

                    rk.SetValue("R_Prag", trbR_Prag.Value);
                    rk.SetValue("G_Prag", trbG_Prag.Value);
                    rk.SetValue("B_Prag", trbB_Prag.Value);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
