﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.Win32;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.GraphicsSystem;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using CADBest.Geometry;
//using AutoCADtest;
using System.Threading;

namespace SixDoFMouse
{
    public class AutoCADManager
    {
        #region Windows functions
        public static float ReadPrefScale()
        {
            RegistryKey sk1 = Registry.CurrentUser.OpenSubKey("Software\\CADBEST\\6DOF Mouse");
            float scale;
            if (sk1 != null)
            {
                scale = (float)Convert.ToDouble(sk1.GetValue("Scale"));
                if (scale == 0)
                    scale = 1;
            }
            else
                scale = 1;
            return scale;
        }

        public static Bitmap ResizeBitmap(float scale, Bitmap source)
        {
            int width, height;
            Bitmap bmp;
            Graphics graph;
            width = (int)(source.Width * scale);
            height = (int)(source.Height * scale);
            bmp = new Bitmap(width, height, source.PixelFormat);
            graph = Graphics.FromImage(bmp);
            graph.DrawImage(source, new Rectangle(0, 0, width, height));
            return bmp;
        }
        #endregion

        #region Thread safe optimization
        // This member is needed for transferring the processing of AutoCAD
        // environment from camera's thread to main thread of AutoCAD
        private static Control syncControl;

        // Delegates used for marshaling the call of corresponding method to main thread of AutoCAD
        private delegate void ModifyViewspaceDelegate(List<Point3D> ViewDesc, bool useTwist);
        private delegate void DrawPolylinesDelegate(List<Point3D> Objects, bool ShouldDeletePrevious, Autodesk.AutoCAD.Colors.Color color);
        private delegate void DrawPlStaticDelegate(List<Point3D> Objects, Color color);
        private delegate void DrawCoordinatesDelegate(List<List<Point3D>> Objects, bool ShouldDelete);

        private void InitializeSyncControl()
        {
            // The control created to help with marshaling
            // needs to be created on the main thread
            syncControl = new Control();
            syncControl.CreateControl();
        }
        #endregion

        #region AutoCAD functions
        // Used for saving the initial state of View
        private readonly ViewTableRecord _initVtr;
        private List<Point3D> _initViewCoordSystem;
        private readonly double _initViewTwist;
        private List<Point3D> _initVtrAngles;
        private readonly Vector3d _initViewDirection;
        private readonly Vector3d _initSideVector;
        private readonly Vector3d _initUpVector;

        private readonly Point3D p000 = new Point3D(0.0, 0.0, 0.0);
        private readonly Point3D p0y0 = new Point3D(0.0, 1.0, 0.0);
        private readonly Point3D[] OriginAlignParametersOXY;
        private readonly Point3D[] _initVtrParameters;

        private SelectionSet currentObjects;

        //public FormVisualizer vizDataText;
        bool first = true;

        public AutoCADManager()
        {
            OriginAlignParametersOXY = new Point3D[] { p000, p0y0, p0y0, p0y0 };
            // Initial view space parameters
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            ViewTableRecord vtr = doc.Editor.GetCurrentView();
            _initVtr = vtr;
            _initViewDirection = vtr.ViewDirection;
            // Side vector is the screen's X axis
            _initSideVector = GetSideVector(_initViewDirection);
            // If there is existing ViewTwist angle rotate the side vector
            // with that angle so it will coincide with the side vector
            if (vtr.ViewTwist > 1e-6)
            {
                _initSideVector = _initSideVector.RotateBy(
                    -vtr.ViewTwist, _initViewDirection);
            }
            // Up vector is screen's Y vector
            _initUpVector = GetUpVector(_initViewDirection, _initSideVector);
            _initViewCoordSystem = GetViewCoordSystem(
                _initViewDirection, _initSideVector, _initUpVector);
            _initViewTwist = vtr.ViewTwist;
            _initVtrAngles = Geometry.GetRotationAngles(_initViewCoordSystem);
            _initVtrParameters = Geometry.align_calc_pars(_initViewCoordSystem[0], _initViewCoordSystem[1], _initViewCoordSystem[2]);

            InitializeSyncControl();
        }

        #region Modify objects

        List<Point3D> ObjCoordinateSystem;

        public void SelectObjects()
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            PromptSelectionResult selectSet = doc.Editor.GetSelection();
            if (selectSet.Status == PromptStatus.OK)
            {
                currentObjects = selectSet.Value;
                ObjCoordinateSystem = new List<Point3D>();
                ObjCoordinateSystem.Add(new Point3D(0.0, 0.0, 0.0)); // Origin
                ObjCoordinateSystem.Add(new Point3D(1.0, 0.0, 0.0)); // X
                ObjCoordinateSystem.Add(new Point3D(0.0, 1.0, 0.0)); // Y
                ObjCoordinateSystem.Add(new Point3D(0.0, 0.0, 1.0)); // Z
            }
        }

        public void SelectionRotate(Document doc, Point3D xyzAngles, Point3D centerCoordinates)
        {
            Database currentDb = doc.Database;
            double[] backRotation = new double[3];

            if (centerCoordinates != null)
            {
                //centerCoordinates.X = Geometry.ValueRound(centerCoordinates.X, 3);
                //centerCoordinates.Y = Geometry.ValueRound(centerCoordinates.Y, 3);
                //centerCoordinates.Z = Geometry.ValueRound(centerCoordinates.Z, 3);

                centerCoordinates.X *= 1;
                //centerCoordinates.Y *= 3;
                centerCoordinates.Z *= -5;
            }

            Point3D translation = ObjCoordinateSystem[0].Clone();
            Geometry.p_add(ObjCoordinateSystem, translation, -1);

            List<Point3D> backRotSinCos = Geometry.GetRotationAngles(ObjCoordinateSystem);
            Geometry.p_rotY(ObjCoordinateSystem, backRotSinCos[1], -1.0);
            Geometry.p_rotZ(ObjCoordinateSystem, backRotSinCos[2], -1.0);
            Geometry.p_rotX(ObjCoordinateSystem, backRotSinCos[0], -1.0);

            backRotation[0] = Geometry.CalculateAngle(backRotSinCos[0]);
            backRotation[1] = Geometry.CalculateAngle(backRotSinCos[1]);
            backRotation[2] = Geometry.CalculateAngle(backRotSinCos[2]);

            List<Point3D> forwardRotSinCos = new List<Point3D>();
            forwardRotSinCos.Add(new Point3D(Math.Sin(xyzAngles.X), Math.Cos(xyzAngles.X), 0));
            forwardRotSinCos.Add(new Point3D(Math.Sin(xyzAngles.Y), Math.Cos(xyzAngles.Y), 0));
            forwardRotSinCos.Add(new Point3D(Math.Sin(xyzAngles.Z), Math.Cos(xyzAngles.Z), 0));

            Geometry.p_rotY(ObjCoordinateSystem, forwardRotSinCos[1], 1.0);
            Geometry.p_rotZ(ObjCoordinateSystem, forwardRotSinCos[2], 1.0);
            Geometry.p_rotX(ObjCoordinateSystem, forwardRotSinCos[0], 1.0);

            if (centerCoordinates != null)
                Geometry.p_add(ObjCoordinateSystem, centerCoordinates, 1.0);
            else
                Geometry.p_add(ObjCoordinateSystem, translation, 1.0);

            foreach (SelectedObject curr in currentObjects)
            {
                using (Transaction trans = currentDb.TransactionManager.StartTransaction())
                {
                    Entity acEntity = trans.GetObject(curr.ObjectId, OpenMode.ForWrite) as Entity;
                    Point3d currentPosition = new Point3d(translation.X, translation.Y, translation.Z);
                    // Back rotation
                    acEntity.TransformBy((Matrix3d.Rotation(
                        -1 * backRotation[1],
                        Vector3d.YAxis,
                        currentPosition)));
                    acEntity.TransformBy((Matrix3d.Rotation(
                        -1 * backRotation[2],
                        Vector3d.ZAxis,
                        currentPosition)));
                    acEntity.TransformBy((Matrix3d.Rotation(
                        -1 * backRotation[0],
                        Vector3d.XAxis,
                        currentPosition)));
                   
                    // Forward rotation
                    acEntity.TransformBy((Matrix3d.Rotation(
                        xyzAngles.Y,
                        Vector3d.YAxis,
                        currentPosition)));
                    acEntity.TransformBy((Matrix3d.Rotation(
                        xyzAngles.Z,
                        Vector3d.ZAxis,
                        currentPosition)));
                    acEntity.TransformBy((Matrix3d.Rotation(
                        xyzAngles.X,
                        Vector3d.XAxis,
                        currentPosition)));

                    if (centerCoordinates != null)
                    {
                        Point3d newPosition = new Point3d(
                            centerCoordinates.X, centerCoordinates.Y, centerCoordinates.Z);
                        Vector3d displacement = currentPosition.GetVectorTo(newPosition);
                        acEntity.TransformBy(Matrix3d.Displacement(displacement));
                    }

                    trans.Commit();
                    AcadApp.UpdateScreen();
                }
            }
        }
        #endregion

        private Vector3d GetSideVector(Vector3d viewDirection)
        {
            return viewDirection.GetPerpendicularVector();
        }

        private Vector3d GetUpVector(Vector3d viewDirection, Vector3d sideVector)
        {
            return viewDirection.CrossProduct(sideVector).GetNormal();
        }

        private List<Point3D> GetViewCoordSystem(Vector3d viewDirection, Vector3d sideVector, Vector3d upVector)
        {
            List<Point3D> viewCoordSystem = new List<Point3D>(4);
            viewCoordSystem.Add(new Point3D(0, 0, 0));
            viewCoordSystem.Add(sideVector.GetPoint3D());
            viewCoordSystem.Add(upVector.GetPoint3D());
            viewCoordSystem.Add(viewDirection.GetPoint3D());
            return viewCoordSystem;
        }

        private List<Point3D> GetViewCoordSystem(ViewTableRecord vtr)
        {
            Vector3d viewDir = vtr.ViewDirection;
            Vector3d sideVector = GetSideVector(viewDir);
            Vector3d upVector = GetUpVector(viewDir, sideVector);

            return GetViewCoordSystem(viewDir, sideVector, upVector);
        }

        //private void SetVtrCoordSystem(List<Point3D> sourceCoord, ViewTableRecord vtr)
        //{
        //    //vtr.ViewDirection = new Vector3d(sourceCoord[3].ToArray());

        //    Point3D ySinCosCurr = Geometry.calc_rotY(sourceCoord[1]);
        //    Geometry.p_rotY(sourceCoord, ySinCosCurr, -1);

        //    Point3D zSinCosCurr = Geometry.calc_rotZ(sourceCoord[1]);
        //    Geometry.p_rotZ(sourceCoord, zSinCosCurr, -1);

        //    Point3D xSinCosCurr = Geometry.calc_rotX(sourceCoord[2]);
        //    Geometry.p_rotX(sourceCoord, xSinCosCurr, -1);
        //}

        public void ModifyViewspace(List<Point3D> MouseAngles, bool useTwist)
        {
            // If ModifyViewspace method is called from different thread, InvokeRequired will be true
            if (syncControl.InvokeRequired)
            {
                syncControl.Invoke(new ModifyViewspaceDelegate(ModifyViewspace), new object[] { MouseAngles, useTwist });
            }
            else
            {
                if (currentObjects == null)
                    return;

                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (doc.LockDocument())
                {
                    Point3D target = null;
                    if (MouseAngles.Count == 2)
                        target = MouseAngles[1];
                    SelectionRotate(doc, MouseAngles[0], target);


                    //ViewTableRecord vtr = (ViewTableRecord)_initVtr.Clone();

                    //List<Point3D> viewCoordSystem = Geometry.CloneList(_initViewCoordSystem);

                    //Geometry.align(viewCoordSystem, _initVtrParameters, OriginAlignParametersOXY);
                    //Geometry.p_rotY(viewCoordSystem, MouseAngles[1], -1);
                    //Geometry.p_rotZ(viewCoordSystem, MouseAngles[2], -1);
                    //Geometry.p_rotX(viewCoordSystem, MouseAngles[0], -1);
                    //Geometry.align(viewCoordSystem, OriginAlignParametersOXY, _initVtrParameters);

                    //SetVtrCoordSystem(viewCoordSystem, vtr);
                    
                    //doc.Editor.SetCurrentView(vtr);

                    //RotateRelativeAngles(doc, MouseAngles[0], useTwist);
                    
                    //RotateView(doc, MouseAngles[0], useTwist);

                    //SetAnglesXYPlane(doc, MouseAngles[0], useTwist);
                    
                    //if (MouseAngles.Count > 1)
                        //{
                        //    MoveView(MouseAngles[1], vtr);
                        //}
                    //}

                    //vizDataText.SetText(
                    //    "angle X: " + Geometry.ConvertToDeg(ViewDesc[0].X).ToString(),
                    //    "angle Y: " + Geometry.ConvertToDeg(ViewDesc[0].Y).ToString(),
                    //    "angle Z: " + Geometry.ConvertToDeg(ViewDesc[0].Z).ToString(),
                    //    "twist  : " + Geometry.ConvertToDeg(vtr.ViewTwist).ToString());
                }
            }
        }

        private void MoveView(Point3D Target, ViewTableRecord vtr)
        {
            if (Target != null)
                //vtr.Target = new Point3d(Target.X, Target.Y, Target.Z);
                vtr.CenterPoint = new Point2d(5 * Target.X, -5 * Target.Y);
        }

        private void SetAnglesXYPlane(Document doc, Point3D angles, bool useTwist)
        {
            double angleInXyPlane = angles.Y;
            double angleFromXyPlane = angles.X;
            Vector3d v1 = Vector3d.XAxis.RotateBy(angleInXyPlane, Vector3d.ZAxis);
            Vector3d v2 = v1.CrossProduct(Vector3d.ZAxis);
            Vector3d viewDir = v1.RotateBy(angleFromXyPlane, v2);

            ViewTableRecord vtr = doc.Editor.GetCurrentView();
            vtr.ViewDirection = viewDir;
            //vtr.clip
            
            doc.Editor.SetCurrentView(vtr);
        }

        private void RotateRelativeAngles(Document doc, Point3D angles, bool useTwist)
        {
            ViewTableRecord vtr = doc.Editor.GetCurrentView();
            Vector3d dirVector = vtr.ViewDirection;
            Vector3d sideVector = vtr.ViewDirection.GetPerpendicularVector();
            if (vtr.ViewTwist > 1e-6)
            {
                sideVector = sideVector.RotateBy(-vtr.ViewTwist, dirVector);
            }
            Vector3d upVector = dirVector.CrossProduct(sideVector).GetNormal();

            // Rotate the view direction vector around Side and Up vectors
            vtr.ViewDirection = vtr.ViewDirection.RotateBy(angles.X, sideVector);
            upVector = upVector.RotateBy(angles.X, sideVector);
            vtr.ViewDirection = vtr.ViewDirection.RotateBy(angles.Y, upVector);

            if (useTwist)
                vtr.ViewTwist = CalcViewTwist(doc, vtr);

            doc.Editor.SetCurrentView(vtr);
        }

        public void RotateView(Document doc, Point3D angles, bool useTwist)
        {
            ViewTableRecord vtr = (ViewTableRecord)_initVtr.Clone();
            vtr.ViewDirection = vtr.ViewDirection.RotateBy(angles.X, _initSideVector);
            vtr.ViewDirection = vtr.ViewDirection.RotateBy(angles.Y, _initUpVector);

            if (useTwist)
                vtr.ViewTwist = CalcViewTwist(doc, vtr);

            // Apply the Z angle rotation
            //vtr.ViewTwist += angles.Z;
            //if (vtr.ViewTwist > Math.PI * 2.0)
            //    vtr.ViewTwist -= Math.PI * 2.0;

            doc.Editor.SetCurrentView(vtr);

            //Functions.DrawTargetViewDir();
        }

        public static double CalcViewTwist(Document doc, ViewTableRecord vtr)
        {
            // The VIEWTWIST system variable represents the angle between the up vector
            // relative to the view direction in WCS and the actual view's up vector in DCS.

            // The following code uses the view direction, and constructs an up vector (which
            // is perpendicular to it). It then calculates the actual up vector of the view,
            // and measures the angle between them.

            // Current View Direction vector, which changes on every rotation
            Vector3d dirVector = vtr.ViewDirection;
            Vector3d sideVector = vtr.ViewDirection.GetPerpendicularVector();
            Vector3d upVector = dirVector.CrossProduct(sideVector).GetNormal();

            // Calculate the actual upVector,
            // by applying the view transformation
            //ewTableRecord currentVtr = doc.Editor.GetCurrentView();
            //currentVtr.ViewTwist = _initialVtr.ViewTwist;
            Matrix3d WCS2DCS = doc.Editor.WCS2DCS();
            Vector3d upVectorDCS = upVector.TransformBy(WCS2DCS);

            // Get the twist angle
            double safeViewTwist = Math.Atan2(upVectorDCS[1], upVectorDCS[0]) - Math.PI / 2;
            if (safeViewTwist < -1e-6)
                safeViewTwist += (Math.PI * 2.0);
            return safeViewTwist;
        }

        // Distance between camera and mouse coordinate system center
        //double PreviousDistance = 0;
        double Width = 0;
        double Height = 0;

        private void RotateViewDest(List<Point3D> ViewDesc, ViewTableRecord vtr)
        {
            if (first == true)
            {
                Width = vtr.Width;
                Height = vtr.Height;
                first = false;
            }
           
            //Point3d view = new Point3d(ViewDesc[0].X, ViewDesc[0].Y, ViewDesc[0].Z);
            //Point3d target = new Point3d(ViewDesc[1].X, ViewDesc[1].Y, ViewDesc[1].Z);
            //vtr.Target = new Point3d(0, 0, 0);
            //vtr.Target = target; // camera around descriptor       
            //Vector3d viewvector = target.GetVectorTo(view);
            //vtr.ViewDirection = viewvector;
            //vtr.ViewDirection = vtr.Target.GetVectorTo(new Point3d(1.5*ViewDesc[0].X, 1.5*ViewDesc[0].Y, 1.5*ViewDesc[0].Z));
            //vtr.ViewDirection =  new Vector3d(ViewDesc[0].X, ViewDesc[0].Y, ViewDesc[0].Z);

            //double zoomDist;
            double currentDist = Geometry.Distance(ViewDesc[3], new Point3D());
            //if (currentDist != null)
            //vizDataText.SetText(currentDist.ToString());

            if ((currentDist > 50) && (currentDist < 160))
            {
                vtr.Width = Width;
                vtr.Height = Height;
            }

            if ((currentDist > 160) && (currentDist < 200))
            {
                vtr.Width = 2 * Width;
                vtr.Height = 2 * Height;
            }
            if ((currentDist > 200) && (currentDist < 300))
            {
                vtr.Width = 4 * Width;
                vtr.Height = 4 * Height;
            }
            if (currentDist > 300) 
            {
                vtr.Width = 6 * Width;
                vtr.Height = 6 * Height;
            }
           
            //if (PreviousDistance != 0)
            //{
            //    zoomDist = PreviousDistance - currentDist;
            //    float zoomFactorIn = 0.7f;
            //    float zoomFactorOut = 1.5f;
            //    if (zoomDist < -5) // Zoom In
            //    {
            //        vtr.Width *= zoomFactorIn;
            //        vtr.Height *= zoomFactorIn;
            //    }
            //    else if (zoomDist > 5) // Zoom Out
            //    {
            //        vtr.Width *= zoomFactorOut;
            //        vtr.Height *= zoomFactorOut;
            //    }
            //}
            //PreviousDistance = currentDist;

            //vtr.CenterPoint = new Point2d(5*ViewDesc[3].X, -5*ViewDesc[3].Y);
        }

        private ObjectId PreviousViewPoint;

        public void DrawPolylines(List<Point3D> Objects, bool ShouldDeletePrevious, Autodesk.AutoCAD.Colors.Color color)
        {
            // If ModifyViewspace method is called from different thread, InvokeRequired will be true
            if (syncControl.InvokeRequired)
                syncControl.Invoke(new DrawPolylinesDelegate(DrawPolylines), new object[] { Objects, ShouldDeletePrevious, color });
            else
            {
                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (DocumentLock docLock = doc.LockDocument())
                {
                    Database currentDb = doc.Database;
                    using (Transaction trans = currentDb.TransactionManager.StartTransaction())
                    {
                        // Deleting the previous drawn object
                        if ((PreviousViewPoint != ObjectId.Null) && (ShouldDeletePrevious))
                        {
                            Entity ent = (Entity)trans.GetObject(PreviousViewPoint, OpenMode.ForWrite);
                            ent.Erase();
                            ent.Dispose();
                        }
                        // Open the Block table for read
                        BlockTable blockTable;
                        blockTable = trans.GetObject(currentDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                        // Open the Block table record Model space for write
                        BlockTableRecord blockTblRec =
                            trans.GetObject(blockTable[BlockTableRecord.ModelSpace],
                            OpenMode.ForWrite) as BlockTableRecord;

                        Point3dCollection plCollection = new Point3dCollection();
                        foreach (Point3D p in Objects)
                        {
                            plCollection.Add(new Point3d(p.X, p.Y, p.Z));
                        }
                        Polyline3d pl = new Polyline3d(Poly3dType.SimplePoly, plCollection, false);
                        pl.Color = color;

                        PreviousViewPoint = blockTblRec.AppendEntity(pl);
                        trans.AddNewlyCreatedDBObject(pl, true);
                        trans.Commit();
                        
                        // Updates the screen without flickering of view
                        AcadApp.UpdateScreen(); // or doc.Editor.Regen();
                    }
                }
            }
        }

        private List<ObjectId> PreviousCoordinates;

        public void DrawCoordinates(List<List<Point3D>> Objects, bool ShouldDelete)
        {
            // If ModifyViewspace method is called from different thread, InvokeRequired will be true
            if (syncControl.InvokeRequired)
                syncControl.Invoke(new DrawCoordinatesDelegate(DrawCoordinates), new object[] { Objects, ShouldDelete });
            else
            {
                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (DocumentLock docLock = doc.LockDocument())
                {
                    Database currentDb = doc.Database;
                    using (Transaction trans = currentDb.TransactionManager.StartTransaction())
                    {
                        if ((PreviousCoordinates != null) && (ShouldDelete))
                        {
                            foreach (ObjectId item in PreviousCoordinates)
                            {
                                Entity ent = (Entity)trans.GetObject(item, OpenMode.ForWrite);
                                ent.Erase();
                                ent.Dispose();
                            }
                        }
                        // Open the Block table for read
                        BlockTable blockTable;
                        blockTable = trans.GetObject(currentDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                        // Open the Block table record Model space for write
                        BlockTableRecord blockTblRec =
                            trans.GetObject(blockTable[BlockTableRecord.ModelSpace],
                            OpenMode.ForWrite) as BlockTableRecord;

                        Autodesk.AutoCAD.Colors.Color[] colors = new Autodesk.AutoCAD.Colors.Color[3];
                        colors[0] = Autodesk.AutoCAD.Colors.Color.FromRgb(255, 0, 0);
                        colors[1] = Autodesk.AutoCAD.Colors.Color.FromRgb(0, 255, 0);
                        colors[2] = Autodesk.AutoCAD.Colors.Color.FromRgb(0, 0, 255);
                        
                        int colorCounter = 0;
                        PreviousCoordinates = new List<ObjectId>();
                        foreach (List<Point3D> plList in Objects)
                        {
                            Point3dCollection plCollection = new Point3dCollection();
                            foreach (Point3D p in plList)
                            {
                                plCollection.Add(new Point3d(p.X, p.Y, p.Z));
                            }
                            Polyline3d pl = new Polyline3d(Poly3dType.SimplePoly, plCollection, false);
                            pl.Color = colors[colorCounter];
                            colorCounter++;

                            PreviousCoordinates.Add(blockTblRec.AppendEntity(pl));
                            trans.AddNewlyCreatedDBObject(pl, true);
                        }
                        trans.Commit();
                        // Updates the screen without flickering of view
                        //doc.Editor.Regen();
                        Autodesk.AutoCAD.ApplicationServices.Application.UpdateScreen();
                    }
                }
            }
        }

        public static void DrawPolylinesStatic(List<Point3D> Objects, Color color)
        {
            // If ModifyViewspace method is called from different thread, InvokeRequired will be true
            if (syncControl.InvokeRequired)
                syncControl.Invoke(new DrawPlStaticDelegate(DrawPolylinesStatic), new object[] { Objects, color });
            else
            {
                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (DocumentLock docLock = doc.LockDocument())
                {
                    Database currentDb = doc.Database;
                    using (Transaction trans = currentDb.TransactionManager.StartTransaction())
                    {
                        // Open the Block table for read
                        BlockTable blockTable;
                        blockTable = trans.GetObject(currentDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                        // Open the Block table record Model space for write
                        BlockTableRecord blockTblRec =
                            trans.GetObject(blockTable[BlockTableRecord.ModelSpace],
                            OpenMode.ForWrite) as BlockTableRecord;

                        Point3dCollection plCollection = new Point3dCollection();
                        foreach (Point3D p in Objects)
                        {
                            plCollection.Add(new Point3d(p.X, p.Y, p.Z));
                        }
                        Polyline3d pl = new Polyline3d(Poly3dType.SimplePoly, plCollection, false);
                        pl.Color = Autodesk.AutoCAD.Colors.Color.FromColor(color);

                        blockTblRec.AppendEntity(pl);
                        trans.AddNewlyCreatedDBObject(pl, true);
                        trans.Commit();

                        // Updates the screen without flickering of view
                        AcadApp.UpdateScreen(); // or doc.Editor.Regen();
                    }
                }
            }
        }
        #endregion
    }

    public enum ScreenAxisRotation
	{
        SideAxis,
        UpAxis,
        Twist
	}

    public class CalcDistanceException : System.ApplicationException
    {
        public CalcDistanceException()
        {
        }

        public CalcDistanceException(string message)
            : base(message)
        {
        }
    } 
}
