﻿using Microsoft.Win32;
using SixDoFMouse.CameraDetection;
using System;
using System.Windows.Forms;

namespace SixDoFMouse
{
    partial class FormWebCamEmgu
    {
         private void ReleaseData()
        {
            if (_capture != null)
                _capture.Dispose();
        }

        private void FormWebCamEmgu_FormClosing(object sender, FormClosingEventArgs e)
        {
            WriteRegistryValues();
            ReleaseData();

            if (USE_RED)
                vizRed.Close();
            if (USE_GREEN)
                vizGreen.Close();
            if (USE_BLUE)
                vizBlue.Close();
            if (USE_YELLOW)
                vizYellow.Close();
            if (SHOW_FILTERS)
                vizFilters.Close();
            vizOriginal.Close();
            if (!vizDataText.IsDisposed)
                vizDataText.Close();
            if (crawlAveragingModule != null)
                crawlAveragingModule.stopwatch.Enabled = false;
            checkBoxCharts.Checked = false;

            Application.Exit();
        }

        private void trackBarBrightness_Scroll(object sender, EventArgs e)
        {
            bool continueCapture = false;
            if (_captureInProgress)
            {
                ResetCapturing(); // Stop the capture
                continueCapture = true;
            }

            if (_capture != null)
                _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_BRIGHTNESS, trackBarBrightness.Value);

            labelBrightness.Text = "Brightness: " + trackBarBrightness.Value;
            if (continueCapture)
                ResetCapturing();
        }

        private void buttonCalibrateCenter_Click(object sender, EventArgs e)
        {
            // Start a calibration
            calibrateModule.IsCalibrate = true;

            //calibrateModule.CalibrationCalcParameters();
        }

        private void checkBoxCharts_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxCharts.Checked)
            {
                chartPoint = new FormChart(30, -500, 500, "Point 1", ChartUpdatingMode.Timed, 500);
                chartPoint.AddCurve("X Axis");
                chartPoint.AddCurve("Y Axis");
                chartPoint.AddCurve("Z Axis");
                chartPoint.Show();
            }
            else
            {
                chartPoint.Close();
            }
        }

        private void checkBoxShowTextViz_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowTextViz.Checked)
            {
                if (vizDataText.IsDisposed)
                    vizDataText = new FormVisualizer(FormVisualizer.DisplayMode.Text, "Text display");
                vizDataText.Show();
            }
            else
                vizDataText.Close();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            TrackBar trackBar = (TrackBar)sender;
            HSVCoeficients coeficients;

            if (radioButtonRed.Checked)
            {
                coeficients = ImageProcessingModule.RedHSVCoef;
            }
            else if (radioButtonGreen.Checked)
            {
                coeficients = ImageProcessingModule.GreenHSVCoef;
            }
            else if (radioButtonBlue.Checked)
            {
                coeficients = ImageProcessingModule.BlueHSVCoef;
            }
            else
            {
                coeficients = ImageProcessingModule.YellowHSVCoef;
            }

            switch (trackBar.Name)
            {
                case "trackBarHDown":
                    coeficients.HueDown = (byte)trackBarHDown.Value;
                    labelHDown.Text = coeficients.HueDown.ToString();
                    break;
                case "trackBarHUp":
                    coeficients.HueUp = (byte)trackBarHUp.Value;
                    labelHUp.Text = coeficients.HueUp.ToString();
                    break;
                case "trackBarSDown":
                    coeficients.SatDown = (byte)trackBarSDown.Value;
                    labelSDown.Text = coeficients.SatDown.ToString();
                    break;
                case "trackBarSUp":
                    coeficients.SatUp = (byte)trackBarSUp.Value;
                    labelSUp.Text = coeficients.SatUp.ToString();
                    break;
                case "trackBarWhite":
                    coeficients.ValueUp = (byte)trackBarWhite.Value;
                    labelUpLevel.Text = coeficients.ValueUp.ToString();
                    break;
                case "trackBarBlack":
                    coeficients.ValueDown = (byte)(trackBarBlack.Value);
                    labelDownLevel.Text = coeficients.ValueDown.ToString();
                    break;
                default:
                    break;
            }
        }

        private void radioButtonColors_CheckedChanged(object sender, EventArgs e)
        {
            LoadHSVValues();
        }

        private void LoadHSVValues()
        {
            HSVCoeficients coeficients;
            if (radioButtonRed.Checked)
            {
                coeficients = ImageProcessingModule.RedHSVCoef;
            }
            else if (radioButtonGreen.Checked)
            {
                coeficients = ImageProcessingModule.GreenHSVCoef;
            }
            else if (radioButtonBlue.Checked)
            {
                coeficients = ImageProcessingModule.BlueHSVCoef;
            }
            else
            {
                coeficients = ImageProcessingModule.YellowHSVCoef;
            }

            trackBarHDown.Value = coeficients.HueDown;
            trackBarHUp.Value = coeficients.HueUp;
            trackBarSDown.Value = coeficients.SatDown;
            trackBarSUp.Value = coeficients.SatUp;
            trackBarBlack.Value = coeficients.ValueDown;
            trackBarWhite.Value = coeficients.ValueUp;

            labelHDown.Text = coeficients.HueDown.ToString();
            labelHUp.Text = coeficients.HueUp.ToString();
            labelSDown.Text = coeficients.SatDown.ToString();
            labelSUp.Text = coeficients.SatUp.ToString();
            labelDownLevel.Text = coeficients.ValueDown.ToString();
            labelUpLevel.Text = coeficients.ValueUp.ToString();
        }

        private void buttonGetWhiteColor_Click(object sender, EventArgs e)
        {
            GetWhiteColor = true;
        }

        //private void trackBarBlackWhite_Scroll(object sender, EventArgs e)
        //{
        //    TrackBar trbSender = (TrackBar)sender;
        //    switch (trbSender.Name)
        //    {
        //        case "trackBarWhite":
        //            UpLevel = (int)(trackBarWhite.Value * 16);
        //            labelUpLevel.Text = UpLevel.ToString();
        //            break;
        //        case "trackBarBlack":
        //            DownLevel = (int)(trackBarBlack.Value * 16);
        //            labelDownLevel.Text = DownLevel.ToString();
        //            break;
        //        default:
        //            break;
        //    }
        //}

        public static void ReadWindowState(RegistryKey rk, object obj, string textRepresentation)
        {
            // Try to cast the object as any Form inheritance
            Form objForm = obj as Form;
            if (obj != null)
            {
                objForm.Top = Convert.ToInt32((string)rk.GetValue(textRepresentation + "Top"));
                objForm.Left = Convert.ToInt32((string)rk.GetValue(textRepresentation + "Left"));
                objForm.Width = Convert.ToInt32((string)rk.GetValue(textRepresentation + "Width"));
                objForm.Height = Convert.ToInt32((string)rk.GetValue(textRepresentation + "Height"));

                FormVisualizer viz = objForm as FormVisualizer;
                if ((viz != null) && (viz.WorkingMode == FormVisualizer.DisplayMode.Emgu))
                {
                    double zoom;
                    if (double.TryParse((string)rk.GetValue(textRepresentation + "Zoom"), out zoom))
                        viz.ZoomScale = zoom;
                }
            }
        }

        private void ReadCheckBoxValues(RegistryKey rk, CheckBox cbControl, string registryItem)
        {
            bool checkBoxChecked;
            if (bool.TryParse((string)rk.GetValue(registryItem), out checkBoxChecked))
                cbControl.Checked = checkBoxChecked;
        }

        private void ReadRegistryValues()
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\" + this.ProductName);
                if ((rk != null) && ((string)rk.GetValue("R_K", "-1") != "-1"))
                {
                    trbR_K.Value = Convert.ToDouble((string)rk.GetValue("R_K"));
                    trbG_K.Value = Convert.ToDouble((string)rk.GetValue("G_K"));
                    trbB_K.Value = Convert.ToDouble((string)rk.GetValue("B_K"));
                    trbY_K.Value = Convert.ToDouble((string)rk.GetValue("Y_K"));

                    trbR_Add.Value = Convert.ToDouble((string)rk.GetValue("R_Add"));
                    trbG_Add.Value = Convert.ToDouble((string)rk.GetValue("G_Add"));
                    trbB_Add.Value = Convert.ToDouble((string)rk.GetValue("B_Add"));
                    trbY_Add.Value = Convert.ToDouble((string)rk.GetValue("Y_Add"));

                    trbR_Prag.Value = Convert.ToDouble((string)rk.GetValue("R_Prag"));
                    trbG_Prag.Value = Convert.ToDouble((string)rk.GetValue("G_Prag"));
                    trbB_Prag.Value = Convert.ToDouble((string)rk.GetValue("B_Prag"));
                    trbY_Prag.Value = Convert.ToDouble((string)rk.GetValue("Y_Prag"));

                    textBoxWidth.Text = (string)rk.GetValue("CaptureWidth");
                    textBoxHeight.Text = (string)rk.GetValue("CaptureHeight");

                    ReadCheckBoxValues(rk, checkBoxShowTextViz, "ShowTextVisualizer");
                    ReadCheckBoxValues(rk, checkBoxSendControlPars, "SendControlPars");
                    ReadCheckBoxValues(rk, checkBoxOldFiltration, "UseOldFiltration");

                    ReadWindowState(rk, this, "Main");
                    ReadWindowState(rk, vizRed, "Red");
                    ReadWindowState(rk, vizGreen, "Green");
                    ReadWindowState(rk, vizBlue, "Blue");
                    ReadWindowState(rk, vizYellow, "Yellow");
                    ReadWindowState(rk, vizFilters, "Filters");
                    ReadWindowState(rk, vizOriginal, "Original");
                    ReadWindowState(rk, vizDataText, "DataText");

                    // Brightness
                    trackBarBrightness.Value = (int)rk.GetValue("Brightness");
                    labelBrightness.Text = "Brightness " + trackBarBrightness.Value.ToString();

                    // Calibration parameters
                    calibrateModule.ReadRegistryCalibration(rk);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Problem occurred while reading registry saved properties");
            }
            finally
            {
                if (rk != null)
                    rk.Dispose();
            }
        }

        private void WriteWindowState(RegistryKey rk, object obj, string textRepresentation)
        {
            // Try to cast the object as any Form inheritance
            Form objForm = obj as Form;
            if (obj != null)
            {
                rk.SetValue(textRepresentation + "Top", objForm.Top.ToString());
                rk.SetValue(textRepresentation + "Left", objForm.Left.ToString());
                rk.SetValue(textRepresentation + "Width", objForm.Width.ToString());
                rk.SetValue(textRepresentation + "Height", objForm.Height.ToString());
                FormVisualizer viz = objForm as FormVisualizer;
                if ((viz != null) && (viz.WorkingMode == FormVisualizer.DisplayMode.Emgu))
                    rk.SetValue(textRepresentation + "Zoom", viz.ZoomScale.ToString());
            }
        }

        private void WriteRegistryValues()
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.LocalMachine.CreateSubKey("SOFTWARE\\" + this.ProductName);
                rk.SetValue("R_K", trbR_K.Value);
                rk.SetValue("G_K", trbG_K.Value);
                rk.SetValue("B_K", trbB_K.Value);
                rk.SetValue("Y_K", trbY_K.Value);

                rk.SetValue("R_Add", trbR_Add.Value);
                rk.SetValue("G_Add", trbG_Add.Value);
                rk.SetValue("B_Add", trbB_Add.Value);
                rk.SetValue("Y_Add", trbY_Add.Value);

                rk.SetValue("R_Prag", trbR_Prag.Value);
                rk.SetValue("G_Prag", trbG_Prag.Value);
                rk.SetValue("B_Prag", trbB_Prag.Value);
                rk.SetValue("Y_Prag", trbY_Prag.Value);

                rk.SetValue("CaptureWidth", textBoxWidth.Text);
                rk.SetValue("CaptureHeight", textBoxHeight.Text);

                rk.SetValue("Brightness", trackBarBrightness.Value);

                rk.SetValue("ShowTextVisualizer", checkBoxShowTextViz.Checked.ToString());
                rk.SetValue("SendControlPars", checkBoxSendControlPars.Checked.ToString());
                rk.SetValue("UseOldFiltration", checkBoxOldFiltration.Checked.ToString());

                // Save window's and visualizer's state
                WriteWindowState(rk, this, "Main");
                WriteWindowState(rk, vizRed, "Red");
                WriteWindowState(rk, vizGreen, "Green");
                WriteWindowState(rk, vizBlue, "Blue");
                WriteWindowState(rk, vizYellow, "Yellow");
                WriteWindowState(rk, vizFilters, "Filters");
                WriteWindowState(rk, vizOriginal, "Original");
                WriteWindowState(rk, vizDataText, "DataText");

                // Calibration parameters
                calibrateModule.WriteRegistryCalibration(rk);
            }
            catch (Exception)
            {
                MessageBox.Show("Error during writing settings in registry!");
            }
            finally
            {
                if (rk != null)
                    rk.Dispose();
            }
        }
    }
}
