﻿using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SixDoFMouse.MousePanel
{
    /// <summary>
    /// It will be used for modifying selection set of AutoCAD entities
    /// </summary>
    public class ModifyObjects
    {
        //ObjectId 
    }
}
