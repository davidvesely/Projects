﻿using CADBest.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SixDoFMouse.CameraDetection
{
    public class MovingAveraging
    {
        private const int TIMER_DISP_PARS_INTERVAL = 3000;
        private const int TIMER_INTERVAL = 10; // in milliseconds
        private const int TIME_LENGTH = 10;
        private const int MIDDLES_LENGTH = 10;
        private const int PERCENT_TOP = 2;

        private List<double> Times = new List<double>(TIME_LENGTH);
        private List<Point3D> Arr0 = new List<Point3D>(MIDDLES_LENGTH);
        private List<Point3D> Arr1 = new List<Point3D>(MIDDLES_LENGTH);
        private List<Point3D> Arr2 = new List<Point3D>(MIDDLES_LENGTH);
        private List<Point3D> Arr3 = new List<Point3D>(MIDDLES_LENGTH);

        public Point3D Middle0 = null;
        public Point3D Middle1 = null;
        public Point3D Middle2 = null;
        public Point3D Middle3 = null;

        public Stopwatch stopwatch; // Measures time between successful frames

        public MovingAveraging()
        {
            stopwatch = new Stopwatch(TIMER_INTERVAL);
            stopwatch.Enabled = true;
        }

        public void CrawlingAveraging(List<Point3D> ViewPoint)
        {
            // FIFO queue
            GatherPoints(Arr0, ViewPoint[0], null, false);
            GatherPoints(Arr1, ViewPoint[1], null, false);
            GatherPoints(Arr2, ViewPoint[2], null, false);
            GatherPoints(Arr3, ViewPoint[3], null, false);

            // Add the time between two successful frames
            // First element from this list should not be used
            double elapsed = stopwatch.ElapsedTime;
            if (Times.Count == TIME_LENGTH)
                Times.RemoveAt(0);
            Times.Add(elapsed);

            if (Arr0.Count < MIDDLES_LENGTH)
                return;

            // Averaging the four lists of points, and retrieve the first derivative
            Point3D dArr0, dArr1, dArr2, dArr3, ddArr0, ddArr1, ddArr2, ddArr3;

            SumAndFirstDerivative(Arr0, ref Middle0, out dArr0, out ddArr0);
            SumAndFirstDerivative(Arr1, ref Middle1, out dArr1, out ddArr1);
            SumAndFirstDerivative(Arr2, ref Middle2, out dArr2, out ddArr2);
            SumAndFirstDerivative(Arr3, ref Middle3, out dArr3, out ddArr3);
        }

        /// <summary>
        /// Calculate Average(Mean) point from sets of points
        /// </summary>
        /// <param name="ArrPoints">Add points to this list</param>
        /// <param name="P1"></param>
        /// <param name="Pmiddle">Previous average point</param>
        /// <param name="ShouldMiddle">If true calculate average points if false add points to ArrPoints</param>
        /// <returns>Average(Mean) point or null if check is false or the element is less that nine </returns>
        private void GatherPoints(List<Point3D> ArrPoints, Point3D P1, Point3D Pmiddle, bool ShouldMiddle)
        {
            if (ArrPoints.Count <= MIDDLES_LENGTH)
            {
                //if ((ArrPoints.Count == MIDDLES_LENGTH - 1) && (Pmiddle != null))
                //{
                //    double xDifference = Math.Abs(P1.X - Pmiddle.X);
                //    double yDifference = Math.Abs(P1.Y - Pmiddle.Y);
                //    double zDifference = Math.Abs(P1.Z - Pmiddle.Z);
                //    double x20percent = Math.Abs(Pmiddle.X * PERCENT_TOP);
                //    double y20percent = Math.Abs(Pmiddle.Y * PERCENT_TOP);
                //    double z20percent = Math.Abs(Pmiddle.Z * PERCENT_TOP);

                //    if ((xDifference > x20percent) ||
                //        (yDifference > y20percent) ||
                //        (zDifference > z20percent))
                //    {
                //        //return null;
                //    }
                //}
                ArrPoints.Add(P1);
            }

            if (ArrPoints.Count > MIDDLES_LENGTH)
            {
                ArrPoints.RemoveAt(0);
                if (ShouldMiddle)
                    MiddlePoints(ArrPoints, Pmiddle);
            }
        }

        private void MiddlePoints(List<Point3D> ArrPoints, Point3D Pmiddle)
        {
            double x = 0, y = 0, z = 0;
            foreach (Point3D p in ArrPoints)
            {
                x += p.X;
                y += p.Y;
                z += p.Z;
            }
            x /= MIDDLES_LENGTH;
            y /= MIDDLES_LENGTH;
            z /= MIDDLES_LENGTH;
            Pmiddle.SetCoordinates(x, y, z);
        }

        private void SumAndFirstDerivative(List<Point3D> PtArr, ref Point3D Middle, out Point3D MiddlePrim, out Point3D MiddlePrim2)
        {
            MiddlePrim2 = null;
            if (PtArr.Count < MIDDLES_LENGTH)
            {
                Middle = null;
                MiddlePrim = null;
                return;
            }

            Point3D MiddlePrevious = Middle;

            // Middled point from the list of input points
            double x = 0, y = 0, z = 0;
            foreach (Point3D p in PtArr)
            {
                x += p.X;
                y += p.Y;
                z += p.Z;
            }
            x /= MIDDLES_LENGTH;
            y /= MIDDLES_LENGTH;
            z /= MIDDLES_LENGTH;
            Middle = new Point3D(x, y, z);

            // First derivative representing the speed of changing of the points
            double dX = 0, dY = 0, dZ = 0;
            for (int i = 0; i < MIDDLES_LENGTH - 1; i++)
            {
                // Times[i + 1] -> the first element in this list should not be used
                dX += ((PtArr[i].X - PtArr[i + 1].X) / Times[i + 1]);
                dY += ((PtArr[i].Y - PtArr[i + 1].Y) / Times[i + 1]);
                dZ += ((PtArr[i].Z - PtArr[i + 1].Z) / Times[i + 1]);
            }
            dX *= (1d / (MIDDLES_LENGTH - 1));
            dY *= (1d / (MIDDLES_LENGTH - 1));
            dZ *= (1d / (MIDDLES_LENGTH - 1));
            MiddlePrim = new Point3D(dX, dY, dZ);

            // Second type
            double sumTime = 0;
            for (int i = 1; i < MIDDLES_LENGTH; i++)
            {
                sumTime += Times[i];
            }
            sumTime /= (MIDDLES_LENGTH - 1);
            if (MiddlePrevious != null)
            {
                MiddlePrim2 = new Point3D();
                MiddlePrim2.X = (Middle.X - MiddlePrevious.X) / sumTime;
                MiddlePrim2.Y = (Middle.Y - MiddlePrevious.Y) / sumTime;
                MiddlePrim2.Z = (Middle.Z - MiddlePrevious.Z) / sumTime;
            }
        }
    }
}
