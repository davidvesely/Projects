﻿namespace SixDoFMouse.CameraDetection
{
    partial class FormStaticFrame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxPixelInfo = new System.Windows.Forms.GroupBox();
            this.labelZoom = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelY = new System.Windows.Forms.Label();
            this.labelX = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.labelG = new System.Windows.Forms.Label();
            this.labelR = new System.Windows.Forms.Label();
            this.groupBoxFiltration = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelBCurrent = new System.Windows.Forms.Label();
            this.labelGCurrent = new System.Windows.Forms.Label();
            this.labelRCurrent = new System.Windows.Forms.Label();
            this.zoomPicBox1 = new SixDoFMouse.ZoomPicBox();
            this.groupBoxBase = new System.Windows.Forms.GroupBox();
            this.labelBBase = new System.Windows.Forms.Label();
            this.labelGBase = new System.Windows.Forms.Label();
            this.labelRBase = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.labelD = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBoxPixelInfo.SuspendLayout();
            this.groupBoxFiltration.SuspendLayout();
            this.groupBoxBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxPixelInfo
            // 
            this.groupBoxPixelInfo.Controls.Add(this.labelZoom);
            this.groupBoxPixelInfo.Controls.Add(this.label1);
            this.groupBoxPixelInfo.Controls.Add(this.label8);
            this.groupBoxPixelInfo.Controls.Add(this.label7);
            this.groupBoxPixelInfo.Controls.Add(this.labelY);
            this.groupBoxPixelInfo.Controls.Add(this.labelX);
            this.groupBoxPixelInfo.Controls.Add(this.label6);
            this.groupBoxPixelInfo.Controls.Add(this.label5);
            this.groupBoxPixelInfo.Controls.Add(this.label4);
            this.groupBoxPixelInfo.Controls.Add(this.labelB);
            this.groupBoxPixelInfo.Controls.Add(this.labelG);
            this.groupBoxPixelInfo.Controls.Add(this.labelR);
            this.groupBoxPixelInfo.Location = new System.Drawing.Point(833, 13);
            this.groupBoxPixelInfo.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxPixelInfo.Name = "groupBoxPixelInfo";
            this.groupBoxPixelInfo.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxPixelInfo.Size = new System.Drawing.Size(181, 124);
            this.groupBoxPixelInfo.TabIndex = 8;
            this.groupBoxPixelInfo.TabStop = false;
            this.groupBoxPixelInfo.Text = "Pixel Info";
            // 
            // labelZoom
            // 
            this.labelZoom.AutoSize = true;
            this.labelZoom.Location = new System.Drawing.Point(54, 101);
            this.labelZoom.Name = "labelZoom";
            this.labelZoom.Size = new System.Drawing.Size(34, 13);
            this.labelZoom.TabIndex = 8;
            this.labelZoom.Text = "Zoom";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Zoom:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(33, 67);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "X:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 84);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Y:";
            // 
            // labelY
            // 
            this.labelY.AutoSize = true;
            this.labelY.Location = new System.Drawing.Point(54, 84);
            this.labelY.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelY.Name = "labelY";
            this.labelY.Size = new System.Drawing.Size(14, 13);
            this.labelY.TabIndex = 5;
            this.labelY.Text = "Y";
            // 
            // labelX
            // 
            this.labelX.AutoSize = true;
            this.labelX.Location = new System.Drawing.Point(54, 67);
            this.labelX.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelX.Name = "labelX";
            this.labelX.Size = new System.Drawing.Size(14, 13);
            this.labelX.TabIndex = 4;
            this.labelX.Text = "X";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 50);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Blue";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 36);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Green";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 22);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Red";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Location = new System.Drawing.Point(54, 50);
            this.labelB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(28, 13);
            this.labelB.TabIndex = 2;
            this.labelB.Text = "Blue";
            // 
            // labelG
            // 
            this.labelG.AutoSize = true;
            this.labelG.Location = new System.Drawing.Point(54, 36);
            this.labelG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelG.Name = "labelG";
            this.labelG.Size = new System.Drawing.Size(36, 13);
            this.labelG.TabIndex = 1;
            this.labelG.Text = "Green";
            // 
            // labelR
            // 
            this.labelR.AutoSize = true;
            this.labelR.Location = new System.Drawing.Point(54, 22);
            this.labelR.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelR.Name = "labelR";
            this.labelR.Size = new System.Drawing.Size(27, 13);
            this.labelR.TabIndex = 0;
            this.labelR.Text = "Red";
            // 
            // groupBoxFiltration
            // 
            this.groupBoxFiltration.Controls.Add(this.labelD);
            this.groupBoxFiltration.Controls.Add(this.labelBCurrent);
            this.groupBoxFiltration.Controls.Add(this.labelGCurrent);
            this.groupBoxFiltration.Controls.Add(this.labelRCurrent);
            this.groupBoxFiltration.Controls.Add(this.label10);
            this.groupBoxFiltration.Controls.Add(this.label9);
            this.groupBoxFiltration.Controls.Add(this.label3);
            this.groupBoxFiltration.Controls.Add(this.label2);
            this.groupBoxFiltration.Location = new System.Drawing.Point(833, 236);
            this.groupBoxFiltration.Name = "groupBoxFiltration";
            this.groupBoxFiltration.Size = new System.Drawing.Size(181, 88);
            this.groupBoxFiltration.TabIndex = 9;
            this.groupBoxFiltration.TabStop = false;
            this.groupBoxFiltration.Text = "Filtration Info";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Red";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 33);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Green";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 50);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Blue";
            // 
            // labelBCurrent
            // 
            this.labelBCurrent.AutoSize = true;
            this.labelBCurrent.Location = new System.Drawing.Point(55, 50);
            this.labelBCurrent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBCurrent.Name = "labelBCurrent";
            this.labelBCurrent.Size = new System.Drawing.Size(36, 13);
            this.labelBCurrent.TabIndex = 15;
            this.labelBCurrent.Text = "Empty";
            // 
            // labelGCurrent
            // 
            this.labelGCurrent.AutoSize = true;
            this.labelGCurrent.Location = new System.Drawing.Point(55, 33);
            this.labelGCurrent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelGCurrent.Name = "labelGCurrent";
            this.labelGCurrent.Size = new System.Drawing.Size(36, 13);
            this.labelGCurrent.TabIndex = 14;
            this.labelGCurrent.Text = "Empty";
            // 
            // labelRCurrent
            // 
            this.labelRCurrent.AutoSize = true;
            this.labelRCurrent.Location = new System.Drawing.Point(55, 16);
            this.labelRCurrent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelRCurrent.Name = "labelRCurrent";
            this.labelRCurrent.Size = new System.Drawing.Size(36, 13);
            this.labelRCurrent.TabIndex = 13;
            this.labelRCurrent.Text = "Empty";
            // 
            // zoomPicBox1
            // 
            this.zoomPicBox1.AutoScroll = true;
            this.zoomPicBox1.AutoScrollMinSize = new System.Drawing.Size(815, 574);
            this.zoomPicBox1.BackColor = System.Drawing.Color.DarkGray;
            this.zoomPicBox1.Image = null;
            this.zoomPicBox1.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            this.zoomPicBox1.Location = new System.Drawing.Point(13, 13);
            this.zoomPicBox1.Name = "zoomPicBox1";
            this.zoomPicBox1.Size = new System.Drawing.Size(815, 574);
            this.zoomPicBox1.TabIndex = 0;
            this.zoomPicBox1.Text = "zoomPicBox1";
            this.zoomPicBox1.Zoom = 1F;
            this.zoomPicBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.zoomPicBox1_MouseClick);
            // 
            // groupBoxBase
            // 
            this.groupBoxBase.Controls.Add(this.labelBBase);
            this.groupBoxBase.Controls.Add(this.labelGBase);
            this.groupBoxBase.Controls.Add(this.labelRBase);
            this.groupBoxBase.Controls.Add(this.label20);
            this.groupBoxBase.Controls.Add(this.label21);
            this.groupBoxBase.Controls.Add(this.label22);
            this.groupBoxBase.Location = new System.Drawing.Point(834, 142);
            this.groupBoxBase.Name = "groupBoxBase";
            this.groupBoxBase.Size = new System.Drawing.Size(181, 88);
            this.groupBoxBase.TabIndex = 17;
            this.groupBoxBase.TabStop = false;
            this.groupBoxBase.Text = "Base Color Info";
            // 
            // labelBBase
            // 
            this.labelBBase.AutoSize = true;
            this.labelBBase.Location = new System.Drawing.Point(55, 50);
            this.labelBBase.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBBase.Name = "labelBBase";
            this.labelBBase.Size = new System.Drawing.Size(36, 13);
            this.labelBBase.TabIndex = 15;
            this.labelBBase.Text = "Empty";
            // 
            // labelGBase
            // 
            this.labelGBase.AutoSize = true;
            this.labelGBase.Location = new System.Drawing.Point(55, 33);
            this.labelGBase.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelGBase.Name = "labelGBase";
            this.labelGBase.Size = new System.Drawing.Size(36, 13);
            this.labelGBase.TabIndex = 14;
            this.labelGBase.Text = "Empty";
            // 
            // labelRBase
            // 
            this.labelRBase.AutoSize = true;
            this.labelRBase.Location = new System.Drawing.Point(55, 16);
            this.labelRBase.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelRBase.Name = "labelRBase";
            this.labelRBase.Size = new System.Drawing.Size(36, 13);
            this.labelRBase.TabIndex = 13;
            this.labelRBase.Text = "Empty";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(22, 50);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(28, 13);
            this.label20.TabIndex = 11;
            this.label20.Text = "Blue";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 33);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(36, 13);
            this.label21.TabIndex = 10;
            this.label21.Text = "Green";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(23, 16);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 13);
            this.label22.TabIndex = 9;
            this.label22.Text = "Red";
            // 
            // labelD
            // 
            this.labelD.AutoSize = true;
            this.labelD.Location = new System.Drawing.Point(55, 67);
            this.labelD.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelD.Name = "labelD";
            this.labelD.Size = new System.Drawing.Size(36, 13);
            this.labelD.TabIndex = 16;
            this.labelD.Text = "Empty";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(35, 67);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "D";
            // 
            // FormStaticFrame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 599);
            this.Controls.Add(this.groupBoxBase);
            this.Controls.Add(this.groupBoxFiltration);
            this.Controls.Add(this.groupBoxPixelInfo);
            this.Controls.Add(this.zoomPicBox1);
            this.Name = "FormStaticFrame";
            this.Text = "FormStaticFrame";
            this.groupBoxPixelInfo.ResumeLayout(false);
            this.groupBoxPixelInfo.PerformLayout();
            this.groupBoxFiltration.ResumeLayout(false);
            this.groupBoxFiltration.PerformLayout();
            this.groupBoxBase.ResumeLayout(false);
            this.groupBoxBase.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ZoomPicBox zoomPicBox1;
        private System.Windows.Forms.GroupBox groupBoxPixelInfo;
        private System.Windows.Forms.Label labelZoom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelY;
        private System.Windows.Forms.Label labelX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label labelG;
        private System.Windows.Forms.Label labelR;
        private System.Windows.Forms.GroupBox groupBoxFiltration;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelBCurrent;
        private System.Windows.Forms.Label labelGCurrent;
        private System.Windows.Forms.Label labelRCurrent;
        private System.Windows.Forms.GroupBox groupBoxBase;
        private System.Windows.Forms.Label labelBBase;
        private System.Windows.Forms.Label labelGBase;
        private System.Windows.Forms.Label labelRBase;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label labelD;
        private System.Windows.Forms.Label label10;
    }
}