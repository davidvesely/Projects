﻿using CADBest.Geometry;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// ********************************************************************************************
//                                        width = cols
//                                       height = rows
// ********************************************************************************************

namespace SixDoFMouse
{
    public static class ImageProcessing
    {
        public static string OpenImageFile()
        {
            using (OpenFileDialog diag = new OpenFileDialog())
            {
                string strFileName = string.Empty;
                //diag.InitialDirectory = "c:\\";
                diag.Filter = "bmp files|*.bmp|jpg files (*.jpg)|*.jpg|png files (*.png)|*.png|All files (*.*)|*.*";
                diag.FilterIndex = 1;
                diag.RestoreDirectory = true;

                if (diag.ShowDialog() == DialogResult.OK)
                    strFileName = diag.FileName;

                //if (strFileName == String.Empty)
                //    return; //user didn't select a file to open
                return strFileName;
            }
        }
        
        public static Color InvertColor(Color c)
        {
            return Color.FromArgb(255 - c.R, 255 - c.G, 255 - c.B);
        }

        public static void ConvertXY(List<List<Point3D>> source, int rows)
        {
            for (int i = 0; i < source.Count; i++)
                ConvertXY(source[i], rows);
        }

        public static void ConvertXY(List<Point3D> source, int rows)
        {
            for (int i = 0; i < source.Count; i++)
                ConvertXY(source[i], rows);
        }

        public static void ConvertXY(Point3D sourceP, int rows)
        {
            sourceP.Y = rows - sourceP.Y;
        }

        private static bool IsBetween(int number, int start, int end)
        {
            if ((start < number) && (number < end))
                return true;
            else
                return false;
        }

        private const int MAX_MIN_SUMS = 10;

        public static SortedSet<PixelData>[] FrameMinMaxPixelSums(byte[,,] imgData)
        {
            SortedSet<PixelData> maxSums = new SortedSet<PixelData>(new PixelDataComparer());
            SortedSet<PixelData> minSums = new SortedSet<PixelData>(new PixelDataComparer());
            //PixelData firstPixel = new PixelData(imgData[0, 0, 2], imgData[0, 0, 1], imgData[0, 0, 0]);
            //maxSums.Add(firstPixel);
            //minSums.Add(firstPixel);
            maxSums.Add(new PixelData());
            minSums.Add(new PixelData(255, 255, 255, 765));

            for (int i = 0; i < imgData.GetLength(0); i++)
            {
                for (int j = 0; j < imgData.GetLength(1); j++)
                {
                    int red = imgData[i, j, 2];
                    int green = imgData[i, j, 1];
                    int blue = imgData[i, j, 0];
                    int currentSum = red + green + blue;

                    // Max Sums set
                    if (currentSum > maxSums.Min.Sum)
                    {
                        bool isAdded = maxSums.Add(new PixelData(red, green, blue, currentSum));
                        if (isAdded && (maxSums.Count > MAX_MIN_SUMS))
                            maxSums.Remove(maxSums.Min);
                    }

                    // Min Sums set
                    if (currentSum < maxSums.Max.Sum)
                    {
                        bool isAdded = minSums.Add(new PixelData(red, green, blue, currentSum));
                        if (isAdded && (minSums.Count > MAX_MIN_SUMS))
                            minSums.Remove(minSums.Max);
                    }
                }
            }

            return new SortedSet<PixelData>[] { maxSums, minSums };
        }
    }

    public enum FilterColors { Blue = 0, Green = 1, Red = 2, Yellow = 3 };

    public struct PixelData
    {
        public int R, G, B;
        public int Sum;

        public PixelData(int aR, int aG, int aB)
        {
            R = aR;
            G = aG;
            B = aB;
            Sum = R + G + B;
        }

        public PixelData(int aR, int aG, int aB, int aSum)
        {
            R = aR;
            G = aG;
            B = aB;
            Sum = aSum;
        }

        public override string ToString()
        {
            return string.Format("Sum = {0}", Sum);
        }
    }

    public class PixelDataComparer : IComparer<PixelData>
    {
        public int Compare(PixelData pix1, PixelData pix2)
        {
            return pix1.Sum.CompareTo(pix2.Sum);
        }
    }

    public struct Strip
    {
        public int start;
        public int end;
        public Strip(int aStart, int aEnd)
        {
            start = aStart;
            end = aEnd;
        }
    }

    public struct WeightCenter
    {
        public int x, y;
        // Used for indicating on which place is
        // located the always black first spot
        public int rowStart;
        public WeightCenter(int aX, int aY, int aRowStart)
        {
            x = aX;
            y = aY;
            rowStart = aRowStart;
        }

        public static readonly WeightCenter Empty = new WeightCenter();
    }

    /// <summary>
    /// Coefficients used during filtration. IM1... and IM2... 
    /// coefficients must be set to 1 on initialization, otherwise RGB filtration will not work
    /// </summary>
    public struct FilteringCoeficients
    {
        public double IM_R_K;// IM1_G, /* <- should be set to 1 -> */ IM1_B;
        public double IM_G_K;// IM2_B, /* <- should be set to 1 -> */ IM2_R;
        public double IM_B_K;// IM3_R, /* <- should be set to 1 -> */ IM3_G;
        public double IM_Y_K;
        public int IM_R_PRAG, IM_R_ADD;
        public int IM_G_PRAG, IM_G_ADD;
        public int IM_B_PRAG, IM_B_ADD;
        public int IM_Y_PRAG, IM_Y_ADD;
    }
}
