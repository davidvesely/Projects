﻿using Emgu.CV;
using Emgu.CV.Features2D;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProperties
{
    public partial class FormWebCamEmgu : Form
    {
        private Capture _capture = null;
        private bool _captureInProgress;
        private FastDetector fastDetect = null;

        private FormVisualizer vizRed, vizGreen, vizBlue, vizFilters, vizOriginal, vizYellow;

        private Image<Bgr, Byte> _frame;
        private Image<Bgr, Byte> cloneOriginal;

        double IM1_R = 1, IM1_G = 1, IM1_B = 1;
        double IM2_G = 1, IM2_R = 1, IM2_B = 1;
        double IM3_B = 1, IM3_R = 1, IM3_G = 1;
        double IM_Y_K = 1;
        int IM_R_PRAG = 512, IM_R_ADD = 512;
        int IM_G_PRAG = 512, IM_G_ADD = 512;
        int IM_B_PRAG = 512, IM_B_ADD = 512;
        int IM_Y_PRAG = 512, IM_Y_ADD = 512;

        Image<Bgr, Byte> imgB;
        Image<Bgr, Byte> imgG;
        Image<Bgr, Byte> imgR;
        Image<Bgr, Byte> imgY;
        Image<Bgr, Byte> imgAll;
        //Image<Bgr, Byte> imgRblur;
        //Image<Gray, Byte> imgRcorner;

        //private VideoWriter vw = new VideoWriter("test.avi", 30, 800, 600, true);

        public FormWebCamEmgu()
        {
            InitializeComponent();
            vizRed = new FormVisualizer(FormVisualizer.DisplayMode.Emgu);
            vizGreen = new FormVisualizer(FormVisualizer.DisplayMode.Emgu);
            vizBlue = new FormVisualizer(FormVisualizer.DisplayMode.Emgu);
            vizFilters = new FormVisualizer(FormVisualizer.DisplayMode.Emgu);
            vizOriginal = new FormVisualizer(FormVisualizer.DisplayMode.Emgu);
            vizYellow = new FormVisualizer(FormVisualizer.DisplayMode.Emgu);
        }

        private void Initialize()
        {
            int width, height;
            width = Convert.ToInt32(textBoxWidth.Text);
            height = Convert.ToInt32(textBoxHeight.Text);
            _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_FRAME_WIDTH, width);
            _capture.SetCaptureProperty(Emgu.CV.CvEnum.CAP_PROP.CV_CAP_PROP_FRAME_HEIGHT, height);
            imgB = new Image<Bgr, Byte>(width, height);
            imgG = new Image<Bgr, Byte>(width, height);
            imgR = new Image<Bgr, Byte>(width, height);
            imgY = new Image<Bgr, Byte>(width, height);
            imgAll = new Image<Bgr, Byte>(width, height);
            
            //imgRblur = new Image<Bgr, Byte>(width, height);
            //imgRcorner = new Image<Gray, Byte>(width, height);
            
            //if (textBoxTreshold.Text != "")
            //    fastDetect = new FastDetector(Convert.ToInt32(textBoxTreshold.Text), true);
            //else
            //    fastDetect = new FastDetector(20, true);
        }

        private void FASTedges(Image<Bgr, byte> source, Bgr color)
        {
            MKeyPoint[] keyPoints = fastDetect.DetectKeyPoints(source.Convert<Gray, byte>(), null);
            foreach (MKeyPoint keypt in keyPoints)
            {
                PointF pt = keypt.Point;
                source.Draw(new CircleF(pt, 2), color, 2);
            }
        }

        private void GetCoefficients()
        {
            IM1_R = trbR_K.Value;
            IM_R_ADD = (int)trbR_Add.Value;
            IM_R_PRAG = (int)trbR_Prag.Value;

            IM2_G = trbG_K.Value;
            IM_G_ADD = (int)trbG_Add.Value;
            IM_G_PRAG = (int)trbG_Prag.Value;

            IM3_B = trbB_K.Value;
            IM_B_ADD = (int)trbB_Add.Value;
            IM_B_PRAG = (int)trbB_Prag.Value;

            IM_Y_K = trbY_K.Value;
            IM_Y_ADD = (int)trbY_Add.Value;
            IM_Y_PRAG = (int)trbY_Prag.Value;
        }

        private void RGBFilter()
        {
            double im;
            byte min;
            byte red, new_red;
            byte green, new_green;
            byte blue, new_blue;
            // Clone frame(imgOriginal is unmanaged memory)
            cloneOriginal = _frame.Convert<Bgr, Byte>();

            byte[,,] data1 = imgR.Data;
            byte[,,] data2 = imgG.Data;
            byte[,,] data3 = imgB.Data;
            byte[,,] dataYellow = imgY.Data;
            byte[,,] dataOriginal = cloneOriginal.Data;
            byte[, ,] dataAll = imgAll.Data;
            //byte[, ,] dataRblur = imgRblur.Data;
            //byte[, ,] dataRcorner = imgRcorner.Data;

            for (int i = cloneOriginal.Rows - 1; i >= 0; i--)
            {
                for (int j = cloneOriginal.Cols - 1; j >= 0; j--)
                {
                    red = dataOriginal[i, j, 2]; //Read to the Red Spectrum
                    green = dataOriginal[i, j, 1]; //Read to the Green Spectrum
                    blue = dataOriginal[i, j, 0]; //Read to the BlueSpectrum

                    //if ((i == 500) && (j == 500))
                    //    MessageBox.Show("Test");

                    //k1 = 384f / (float)(red + green + blue + 10);
                    //red = (byte)(k1 * red);
                    //green = (byte)(green * k1);
                    //blue = (byte)(blue * k1);



                    min = red;
                    if (min > green)
                        min = green;
                    if (min > blue)
                        min = blue;
                    red = (byte)(red - min);
                    green = (byte)(green - min);
                    blue = (byte)(blue - min);

                    //if (red == 0)
                    //{
                    //    min = Math.Min(green, blue);
                    //    green = (byte)(green - min);
                    //    blue = (byte)(blue - min);
                    //}
                    //else if (green == 0)
                    //{
                    //    min = Math.Min(red, blue);
                    //    red = (byte)(red - min);
                    //    blue = (byte)(blue - min);
                    //}
                    //else
                    //{
                    //    min = Math.Min(green, green);
                    //    red = (byte)(red - min);
                    //    green = (byte)(green - min);
                    //}

                    dataOriginal[i, j, 2] = red; //Read to the Red Spectrum
                    dataOriginal[i, j, 1] = green; //Read to the Green Spectrum
                    dataOriginal[i, j, 0] = blue; //Read to the BlueSpectrum

                    if (checkBox1.Checked)
                    {
                        im = red * IM1_R - green * IM1_G - blue * IM1_B + IM_R_ADD;
                        //im = (2 * Math.Pow(red, 3)) / (1.0 + Math.Pow(green, 3) + Math.Pow(blue, 3));
                        if (im >= IM_R_PRAG)
                        //if (im >= 4*IM_R_PRAG)
                            new_red = 255;
                        else
                            new_red = 0;
                    }
                    else
                        new_red = red;
                    data1[i, j, 2] = new_red;
                    data1[i, j, 1] = 0;
                    data1[i, j, 0] = 0;

                    if (checkBox1.Checked)
                    {
                        im = green * IM2_G - red * IM2_R - blue * IM2_B + IM_G_ADD;
                        if (im >= IM_G_PRAG)
                            new_green = 255;
                        else
                            new_green = 0;
                    }
                    else
                        new_green = green;
                    data2[i, j, 2] = 0;
                    data2[i, j, 1] = new_green;
                    data2[i, j, 0] = 0;

                    if (checkBox1.Checked)
                    {
                        im = blue * IM3_B - green * IM3_G - red * IM3_R + IM_B_ADD;
                        if (im >= IM_B_PRAG)
                            new_blue = 255;
                        else
                            new_blue = 0;
                    }
                    else
                        new_blue = blue;
                    data3[i, j, 2] = 0;
                    data3[i, j, 1] = 0;
                    data3[i, j, 0] = new_blue;

                    dataAll[i, j, 2] = new_red;
                    dataAll[i, j, 1] = new_green;
                    dataAll[i, j, 0] = new_blue;

                    //Yellow
                    if (checkBox1.Checked)
                    {
                        //im = blue * IM3_B - green * IM3_G - red * IM3_R + IM_B_ADD;
                        im = IM_Y_K * (0.8 * red + green) - 2*blue + IM_Y_ADD;
                        if (im >= IM_Y_PRAG)
                        {
                            new_red = 255;
                            new_green = 255;
                            dataAll[i, j, 2] = new_red;
                            dataAll[i, j, 1] = new_green;
                        }
                        else
                        {
                            new_red = 0;
                            new_green = 0;
                        }
                    }
                    else
                    {
                        new_blue = blue;
                        new_green = green;
                    }
                    dataYellow[i, j, 2] = new_red;
                    dataYellow[i, j, 1] = new_green;
                    dataYellow[i, j, 0] = 0;


                    //dataAll[i, j, 1] += (byte)(new_green / 2);
                    //dataAll[i, j, 0] += (byte)(new_blue / 2);

                    //data3[i, j, 2] = (byte)(255 - new_blue);//new_red;
                    //data3[i, j, 1] = (byte)(255 - new_blue);// new_green;
                    //data3[i, j, 0] = 255;



                    //if ((i == 600) && (j == 500))
                    //    MessageBox.Show("Test");

                    //data1[i, j, 2] = (byte)((255 + red - green - blue) / 2); //Red
                    //data1[i, j, 1] = data1[i, j, 0] = 0;

                    //data2[i, j, 1] = (byte)((255 + green - red - blue) / 2); //Green
                    //data2[i, j, 2] = data2[i, j, 0] = 0;

                    //data3[i, j, 0] = (byte)((255 + blue - green - red) / 2); //Blue
                    //data3[i, j, 2] = data3[i, j, 1] = 0;
                }
            }

            //Filters.Gaussian(data1, dataRblur, cloneOriginal.Rows, cloneOriginal.Cols, Filters.ColorChannels.Red);
            //Filters.Filter3x3(cloneOriginal.Convert<Gray, byte>().Data, dataRcorner, cloneOriginal.Rows, cloneOriginal.Cols, Filters.ColorChannels.Gray, Filters.Matrix3x3.Sobel);
            //cloneOriginal.PyrDown().PyrUp();
            //FASTedges(cloneOriginal, new Bgr(0, 0, 255));
        }

        private void ProcessFrame(object sender, EventArgs arg)
        {
            _frame = _capture.RetrieveBgrFrame().Flip(Emgu.CV.CvEnum.FLIP.HORIZONTAL);

            //Image<Gray, Byte> grayFrame = _frame.Convert<Gray, Byte>().PyrDown().PyrUp();
            //Image<Gray, Byte> smallGrayFrame = grayFrame.PyrDown();
            //Image<Gray, Byte> smoothedGrayFrame = smallGrayFrame.PyrUp();
            //MKeyPoint[] keyPoints = fastDetect.DetectKeyPoints(grayFrame, null);
            //Image<Bgr, Byte> image = _frame.Clone();
            //foreach (MKeyPoint keypt in keyPoints)
            //{
            //    PointF pt = keypt.Point;
            //    image.Draw(new CircleF(pt, 2), new Bgr(0, 0, 255), 2);
            //}

            //imageBox1.Image = image;
            GetCoefficients();
            RGBFilter();
            FindSpots(imgR.Data, imgR.Data, cloneOriginal.Rows, cloneOriginal.Cols, FilterColors.Red);
            FindSpots(imgG.Data, imgG.Data, cloneOriginal.Rows, cloneOriginal.Cols, FilterColors.Green);
            FindSpots(imgB.Data, imgB.Data, cloneOriginal.Rows, cloneOriginal.Cols, FilterColors.Blue);

            //FASTedges(imgR, new Bgr(255, 0, 0));
            //FASTedges(imgG, new Bgr(0, 0, 255));
            //FASTedges(imgB, new Bgr(0, 255, 0));
            //imageBox1.Image = cloneOriginal;
            //imageBoxR.Image = imgR;
            vizRed.SetPicture(imgR);
            vizGreen.SetPicture(imgG);
            vizBlue.SetPicture(imgB);
            vizFilters.SetPicture(cloneOriginal);
            vizOriginal.SetPicture(_frame);
            //imageBoxG.Image = imgG;
            //imageBoxB.Image = imgB;
            //imageBoxY.Image = imgY;
            //imageBoxAll.Image = imgAll;
            //vw.WriteFrame(imgRblur);
            //imageBoxB.Image = imgB;
            //imageBoxB.Image = imgGray;
        }

        #region WebCam and UI
        private void FormWebCamEmgu_Load(object sender, EventArgs e)
        {
            //Read coefficients from registry
            ReadRegistryValues();
        }

        private void buttonCapture_Click(object sender, EventArgs e)
        {
            if (_captureInProgress)
            {  //stop the capture
                buttonCapture.Text = "Start Capture";
                _capture.Pause();
                _capture.ImageGrabbed -= ProcessFrame;
            }
            else
            {
                //start the capture
                buttonCapture.Text = "Stop";
                try
                {
                    int choice;
                    if (radioButton1.Checked)
                        choice = 0;
                    else
                        choice = 1;
                    _capture = new Capture(choice);
                    _capture.ImageGrabbed += ProcessFrame;
                }
                catch (NullReferenceException excpt)
                {
                    MessageBox.Show(excpt.Message);
                }
                Initialize();
                _capture.Start();
            }

            _captureInProgress = !_captureInProgress;

            vizRed.Show();
            vizGreen.Show();
            vizBlue.Show();
            vizFilters.Show();
            vizOriginal.Show();
            vizYellow.Show();
        }

        private void ReleaseData()
        {
            if (_capture != null)
                _capture.Dispose();
        }

        private void FormWebCamEmgu_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Writing coefficients to memory
            WriteRegistryValues();

            ReleaseData();
            Application.Exit();
        }

        private void ReadRegistryValues()
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\" + Application.ProductName);
                if (rk != null)
                {
                    trbR_K.Value = Convert.ToDouble((string)rk.GetValue("R_K"));
                    trbG_K.Value = Convert.ToDouble((string)rk.GetValue("G_K"));
                    trbB_K.Value = Convert.ToDouble((string)rk.GetValue("B_K"));
                    trbY_K.Value = Convert.ToDouble((string)rk.GetValue("Y_K"));

                    trbR_Add.Value = Convert.ToDouble((string)rk.GetValue("R_Add"));
                    trbG_Add.Value = Convert.ToDouble((string)rk.GetValue("G_Add"));
                    trbB_Add.Value = Convert.ToDouble((string)rk.GetValue("B_Add"));
                    trbY_Add.Value = Convert.ToDouble((string)rk.GetValue("Y_Add"));

                    trbR_Prag.Value = Convert.ToDouble((string)rk.GetValue("R_Prag"));
                    trbG_Prag.Value = Convert.ToDouble((string)rk.GetValue("G_Prag"));
                    trbB_Prag.Value = Convert.ToDouble((string)rk.GetValue("B_Prag"));
                    trbY_Prag.Value = Convert.ToDouble((string)rk.GetValue("Y_Prag"));

                    textBoxWidth.Text = (string)rk.GetValue("CaptureWidth");
                    textBoxHeight.Text = (string)rk.GetValue("CaptureHeight");
                    //}
                }
            }
            catch (Exception)
            {
            }
            finally
            {
                rk.Dispose();
            }
        }

        private void WriteRegistryValues()
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.LocalMachine.CreateSubKey("SOFTWARE\\" + Application.ProductName);
                rk.SetValue("R_K", trbR_K.Value);
                rk.SetValue("G_K", trbG_K.Value);
                rk.SetValue("B_K", trbB_K.Value);
                rk.SetValue("Y_K", trbY_K.Value);

                rk.SetValue("R_Add", trbR_Add.Value);
                rk.SetValue("G_Add", trbG_Add.Value);
                rk.SetValue("B_Add", trbB_Add.Value);
                rk.SetValue("Y_Add", trbY_Add.Value);

                rk.SetValue("R_Prag", trbR_Prag.Value);
                rk.SetValue("G_Prag", trbG_Prag.Value);
                rk.SetValue("B_Prag", trbB_Prag.Value);
                rk.SetValue("Y_Prag", trbY_Prag.Value);

                rk.SetValue("CaptureWidth", textBoxWidth.Text);
                rk.SetValue("CaptureHeight", textBoxHeight.Text);
            }
            catch (Exception)
            {
            }
            finally
            {
                rk.Dispose();
            }
        }
        #endregion

        private void buttonSpot_Click(object sender, EventArgs e)
        {
            Image<Bgr, Byte> input = new Image<Bgr, Byte>("test1.bmp");
            Image<Bgr, Byte> dest = new Image<Bgr, Byte>(input.Rows, input.Cols);
            //FindSpots(input.Data, input.Data, input.Rows, input.Cols, FilterColors.Red);
            FindSpots(input.Data, input.Data, input.Rows, input.Cols, FilterColors.Blue);
            imageBoxR.Image = input;
        }

        struct Strip
        {
            public int start;
            public int end;
        }

        struct WeightCenter
        {
            public int x, y;
            public int relX, relY;
        }

        enum FilterColors { Blue = 0, Green = 1, Red = 2, Yellow = 3 };

        private void FindStrips(byte[, ,] source, int strip_direction, int elements, Strip[] strip, FilterColors color, bool isRows) //Check columns or rows for strips with pixels
        {
            int currentStrip = 0;
            int i, j;
            for (i = 0; i < strip_direction; i++)
            {
                j = 0;
                switch (isRows)
                {
                    case true:
                        while ((j < elements) && (source[i, j, (int)color] != 255)) // Find pixels and stop until first founded on the current row
                            j++;
                        break;
                    case false:
                        while ((j < elements) && (source[j, i, (int)color] != 255)) // Find pixels and stop until first founded on the current col
                            j++;
                        break;
                }
                if (j < elements) //If a pixel is found
                {
                    strip[currentStrip].start = i; //Mark its start
                    do //Find the last row with pixels
                    {
                        j = 0;
                        i++;
                        if (i == strip_direction)
                            break;
                        switch (isRows)
                        {
                            case true:
                                while ((j < elements) && (source[i, j, (int)color] != 255)) // Find pixels and stop until first founded on the current row
                                    j++;
                                break;
                            case false:
                                while ((j < elements) && (source[j, i, (int)color] != 255)) // Find pixels and stop until first founded on the current col
                                    j++;
                                break;
                        }
                    } while (j < elements); // if j == cols -> therefore we've found an empty row
                    strip[currentStrip].end = i - 1; //Mark the end of a strip with last row with pixels
                    if ((strip[currentStrip].end - strip[currentStrip].start) > 5) //If the strip is with normal width > 5 rows jump to next strip
                        currentStrip++;
                    else                                                           //otherwise ignore the current strip
                    {
                        strip[currentStrip].end = 0;
                        strip[currentStrip].start = 0;
                    }
                }
            }
        }

        private void FindSpots(byte[, ,] source, byte[, ,] destination, int rows, int cols, FilterColors color)
        {
            int st_row = 0, st_col = 0;
            int wx, wy;
            int x1, y1, x2, y3;
            int countWeights = 0;
            WeightCenter[] weights = new WeightCenter[100];
            Strip[] RowStrips = new Strip[100];
            Strip[] ColStrips = new Strip[100];
            
            FindStrips(source, rows, cols, RowStrips, color, true); //True for rows
            FindStrips(source, cols, rows, ColStrips, color, false); //False for cols
            
            while (RowStrips[st_row].start != 0)
            {
                while (ColStrips[st_col].start != 0)
                {
                    x1 = ColStrips[st_col].start;
                    y1 = RowStrips[st_row].start;

                    x2 = ColStrips[st_col].end;

                    y3 = RowStrips[st_row].end;

                    st_col++;
                    CalculateWeightCenter(source, x1, y1, x2 - x1 + 1, y3 - y1 + 1, countWeights, weights, color);
                    if ((weights[countWeights].x > 0) && (weights[countWeights].y > 0)) // Visualize weight centres
                    {
                        wx = weights[countWeights].x + weights[countWeights].relX;
                        wy = weights[countWeights].y + weights[countWeights].relY;
                        destination[wy, wx, 2] = destination[wy, wx, 1] = destination[wy, wx, 0] = 255;
                        destination[wy - 1, wx, 2] = destination[wy - 1, wx, 1] = destination[wy - 1, wx, 0] = 255;
                        destination[wy, wx - 1, 2] = destination[wy, wx - 1, 1] = destination[wy, wx - 1, 0] = 255;
                        destination[wy - 1, wx - 1, 2] = destination[wy - 1, wx - 1, 1] = destination[wy - 1, wx - 1, 0] = 255;
                        countWeights++;
                    }
                }
                st_row++;
                st_col = 0;
            } // End While - drawing
        } // End FindSpots

        private void CalculateWeightCenter(byte[, ,] source, int x, int y, int width, int height, int countWeights, WeightCenter[] weight, FilterColors color)
        {
            int sum_x = 0, sum_y = 0, n = 0;
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (source[i + y, j + x, (byte)color] == 255)
                    {
                        sum_x += j;
                        sum_y += i;
                        n++;
                    }
                }
            }
            if (n > 0)
            {
                weight[countWeights].x = x;
                weight[countWeights].y = y;
                weight[countWeights].relX = (int)sum_x / n;
                weight[countWeights].relY = (int)sum_y / n;
            }
        }

        private void buttonTestViz_Click(object sender, EventArgs e)
        {
            
        }
    }
}
