﻿// (C) Copyright 2013 by  
//
using System;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;
using CADBest.Geometry;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using System.Collections.Generic;

[assembly: CommandClass(typeof(SixDoFMouse.MyCommands))]

namespace SixDoFMouse
{
    public class MyCommands
    {
        [CommandMethod("CADBEST", "PANEL6DOF", "PANEL6DOF", CommandFlags.Modal)]
        public void MyCommand()
        {
            FormControls form = new FormControls();
            form.Show();
        }
    }
}
