﻿using CADBest.Geometry;
using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace SixDoFMouse.CameraDetection
{
    public class MouseRecognition
    {
        // The border between black and white binary spots
        private const int BW_LIMIT = 290;
        private MouseDataContainer dataMouse = MouseDataContainer.Instance;
        
        // For testing
        //public FormVisualizer mainTextViz;
        //public Image<Bgr, byte> imgVisualizePoints;

        /// <summary>
        /// Detect the orientation of camera toward descriptor
        /// </summary>
        /// <param name="filtered">Filtered image array</param>
        /// <param name="original">Original image array</param>
        /// <param name="color">Define which color filter is used</param>
        /// <returns>Four points. Camera place, center 
        /// of projection and two orientations(X and Y)</returns>
        public List<Point3D> Detection(
            Image<Bgr, byte> imgContainer,
            byte[, ,] original, FilterColors color,
            int FrameRows, int FrameCols,
            List<Point3D> CenterProjXY,
            ref Color spotColor)
        {
            //spotColor = Color.Empty;
            FilterColors frameColor = color;
            // Correction is made for yellow color, which value is 4,
            // but a image array consists only of three color channels.
            // The color is used as index in that array
            if (color == FilterColors.Y)
                color = FilterColors.R;

            List<WeightCenter> sp = SpotDetection.FindSpots(imgContainer.Data, original, color, FrameRows, FrameCols);
            if (sp == null)
                return null;

            Point3D[][] orientation = DetectFace(sp, FrameRows);

            // In case five color spots are detected the processing of current frame continues
            if (orientation == null)
                return null;

            WeightCenter binFound;
            List<Point3D> bin8Location = CalcBinaryPlaces(original, orientation[0], orientation[1], out binFound);
            int sideNumber = ReadBinaryCode(original, bin8Location);
            if (sideNumber < 0)
                return null;

            #region Visualization of binary code location
            //if (imgVisualizePoints != null)
            //{
            //    int rows = original.GetLength(0);
            //    int cols = original.GetLength(1);
            //    Visualization.DrawPoints(imgVisualizePoints.Data, binar8Codes, rows, cols);
            //}                     
            //Number 3 has problem
            //if (color == FilterColors.Blue)
            //    mainTextViz.SetText(sideNumber.ToString());
            #endregion

            // Compare side number and color if they match correctly
            if (!CheckSideNumberColor(sideNumber, frameColor))
                return null;

            List<Point3D> fourPdescriptor = new List<Point3D>(5);
            fourPdescriptor.Add(dataMouse.ColorSpotsDescriptorSmall[0]);
            fourPdescriptor.Add(dataMouse.ColorSpotsDescriptorSmall[1]);
            fourPdescriptor.Add(dataMouse.ColorSpotsDescriptorSmall[2]);
            fourPdescriptor.Add(dataMouse.ColorSpotsDescriptorSmall[3]);
            fourPdescriptor.Add(dataMouse.ColorSpotsDescriptorSmall[4]);
            Point3D[] cameraProjectionPoints = orientation[2];

            int binPosition = binFound.rowStart;

            List<Point3D> fourPprojection = new List<Point3D>(4);
            // Order points in counter clock wise from binary code
            fourPprojection.Add(cameraProjectionPoints[dataMouse.indexBinaryPositionReorder[binPosition, 0]]);
            fourPprojection.Add(cameraProjectionPoints[dataMouse.indexBinaryPositionReorder[binPosition, 1]]);
            fourPprojection.Add(cameraProjectionPoints[dataMouse.indexBinaryPositionReorder[binPosition, 2]]);
            fourPprojection.Add(cameraProjectionPoints[dataMouse.indexBinaryPositionReorder[binPosition, 3]]);
            fourPprojection.Add(cameraProjectionPoints[dataMouse.indexBinaryPositionReorder[binPosition, 4]]);

            //For distance check
            List<Point3D> FoundSpots = Geometry.CloneList(fourPprojection);

            ImageProcessing.ConvertXY(fourPprojection, FrameRows);

            // Averaging two result from 4-point transformation
            List<Point3D> pl1, pl2;
            pl1 = fourPdescriptor.GetRange(0, 4);
            pl2 = fourPprojection.GetRange(0, 4);
            List<List<Point3D>> fourPone = Geometry.cal_4p_trans(pl1, CenterProjXY, pl2);
            pl1 = fourPdescriptor.GetRange(1, 4);
            pl1.Reverse();
            pl2 = fourPprojection.GetRange(1, 4);
            pl2.Reverse();
            List<List<Point3D>> fourPtwo = Geometry.cal_4p_trans(pl1, CenterProjXY, pl2);
            if ((fourPone == null) || (fourPtwo == null))
                return null;
            List<Point3D> fourP = AverageViewPoints(fourPone[1], fourPtwo[1]);
            //List<Point3D> fourP = fourPone[1];

            Point3D[] sourceViewPars = Geometry.align_calc_pars(new Point3D[] {
                dataMouse.ColorSpotsDescriptorSmall[0],
                dataMouse.ColorSpotsDescriptorSmall[1],
                dataMouse.ColorSpotsDescriptorSmall[2]
            });

            // sideNumber-1 is the index of the detected side
            Point3D[] destViewPars = Geometry.align_calc_pars(new Point3D[] {
                dataMouse.ColorSpotSides[sideNumber - 1][0],
                dataMouse.ColorSpotSides[sideNumber - 1][1],
                dataMouse.ColorSpotSides[sideNumber - 1][2]
            });

            // Descriptor parameters of camera
            Geometry.align(fourP, sourceViewPars, destViewPars);

            if (!DistanceCheck(fourP, FoundSpots, sideNumber, CenterProjXY, FrameRows))
                return null;

            if (spotColor == Color.Empty)
                spotColor = ImageProcessing.ModifyColor(ImageProcessing.GetColor(original, sp[0], 1));

            //Visualization.ProjectDescriptorPoints(fourP[1], sideNumber, CenterProjXY, imgOriginal, FrameRows, FrameCols, 100); // Dobri visualization
            //Vizualization.ProjectDescriptor(fourP[1], sideNumber, centerProjXY, imgR, FrameRows);
            //Visualization.ProjectDescriptorPoints(fourP[1], sideNumber, CenterProjXY, imgOriginal, FrameRows, FrameCols, 100);
            //Vizualization.DrawPoints(imgR.Data, fourP[1], FrameRows, FrameCols);

            return fourP;
        }

        /// <summary>
        /// Check distance between found weight centers and projected centers 
        /// </summary>
        /// <param name="fourP">Four points. Camera place, center of projection and two orientations(X and Y)</param>
        /// <param name="FoundSpots">Found and Ordered points in counter clock wise from binary code</param>
        /// <param name="sidenumber">Side number</param>
        /// <param name="CenterProjXY">Center of projection. X and Y axis middle</param>
        /// <param name="FrameRows">Frame rows</param>
        /// <returns>True if pass.</returns>
        private bool DistanceCheck(List<Point3D> fourP, List<Point3D> FoundSpots, int sidenumber, List<Point3D> CenterProjXY, int FrameRows)
        {
            List<List<Point3D>> ProjectedPointsOfDescriptor = new List<List<Point3D>>();
            ProjectedPointsOfDescriptor.Add(Visualization.DescriptorPointsOnImage(fourP, sidenumber, CenterProjXY, FrameRows));

            //Visualization.ProjectDescriptorPoints(fourP, sideNumber, CenterProjXY, imgContainer, FrameRows, FrameCols, 100);
            //Visualization.DrawPoints(imgOriginal.Data, fourP[1], FrameRows, FrameCols);

            double dist = 0;
            //Check the difference between Found spot and projected points
            for (int i = 0; i < 4; i++)
            {
                ProjectedPointsOfDescriptor[0][i].Z = 0;
                dist = Geometry.Distance(ProjectedPointsOfDescriptor[0][i], FoundSpots[i]);
                //vizDataText.SetText(dist.ToString());
                if (dist > 8)
                    return false;               
            }
            return true;
        }

        /// <summary>
        /// Find the correct order of detected color spots and calculate the orientation parameters
        /// </summary>
        /// <param name="weights">Weight centers of color spots, unordered</param>
        /// <returns>Orientation parameters of descriptor and projection from camera,
        /// and correctly reordered points from projection</returns>
        private Point3D[][] DetectFace(List<WeightCenter> weights, int FrameRows)
        {
            // Five points from the sides descriptor - destination for homography
            Point3D[] destP = dataMouse.ColorSpotsDescriptorSmall;
            Point3D[] destPars_fourthP = Geometry.homography_calc_pars(
                new Point3D[] { destP[0], destP[1], destP[2], destP[4] });
            Point3D[] destPars_fifthP = Geometry.homography_calc_pars(
                new Point3D[] { destP[0], destP[1], destP[2], destP[3] });
            Point3D[][] destPars = new Point3D[][] { destPars_fourthP, destPars_fifthP };
            double distance;
            double distanceMin = 10000;
            List<Point3D> homographyRes, weightListCurrent;
            List<Point3D> homographyMin = null, weightListMin = null;
            Point3D[] hmMinSourcePars = null, hmMinDestPars = null;

            // Convert the WeightCenter struct to List of Point3D
            List<Point3D> weightsList = new List<Point3D>(15);
            foreach (WeightCenter item in weights)
                weightsList.Add(new Point3D(item.x, item.y, 0));

            for (int i = 0; i < 6; i++)
            {
                weightListCurrent = new List<Point3D>(10);
                for (int j = 0; j < 4; j++)
                {
                    weightListCurrent.Add(weightsList[dataMouse.indexWeightsDetect[i, j]]);
                }
                Point3D[] sourcePars = Geometry.homography_calc_pars(weightListCurrent.ToArray());
                weightListCurrent.Add(weightsList[4]);

                for (int j = 0; j <= 1; j++)
                {
                    homographyRes = Geometry.homography_calc(weightListCurrent, sourcePars, destPars[j]);
                    distance = Geometry.Distance(homographyRes[4], destP[j + 3]);
                    if (distance < distanceMin)
                    {
                        distanceMin = distance;
                        homographyMin = homographyRes;
                        weightListMin = weightListCurrent;
                        hmMinSourcePars = sourcePars;
                        hmMinDestPars = destPars[j];
                        // For correct order of points
                        if (j == 0) // This should be fixed in future
                        {
                            Point3D pTemp = homographyMin[3];
                            homographyMin[3] = homographyMin[4];
                            homographyMin[4] = pTemp;

                            pTemp = weightListMin[3];
                            weightListMin[3] = weightListMin[4];
                            weightListMin[4] = pTemp;
                        }
                    }
                }
            }

            if (distanceMin < 1)
            {
                // If true is returned, recalc parameters
                Point3D[] sourceBinPars, destBinPars;
                if (CheckOrder(weightListMin, FrameRows))
                {
                    sourceBinPars = destPars_fifthP;
                    destBinPars = Geometry.homography_calc_pars(
                        new Point3D[] { weightListMin[0], weightListMin[1], weightListMin[2], weightListMin[3] });
                }
                else
                {
                    sourceBinPars = hmMinDestPars;
                    destBinPars = hmMinSourcePars;
                }

                Point3D[][] resultOrientation = new Point3D[][] { 
                    sourceBinPars, destBinPars, weightListMin.ToArray()
                };
                return resultOrientation;
            }
            else
                return null;
        }

        // Used in Detection method
        private List<Point3D> AverageViewPoints(List<Point3D> vp1, List<Point3D> vp2)
        {
            if ((vp1.Count != 4) || (vp2.Count != 4))
                return null;

            List<Point3D> vpResult = new List<Point3D>();

            for (int i = 0; i < vp1.Count; i++)
            {
                double x, y, z;
                x = (vp1[i].X + vp2[i].X) / 2;
                y = (vp1[i].Y + vp2[i].Y) / 2;
                z = (vp1[i].Z + vp2[i].Z) / 2;
                vpResult.Add(new Point3D(x, y, z));
            }
            return vpResult;
        }

        /// <summary>
        /// Check for correct order of detected points from camera
        /// If the order is clockwise, it is reversed
        /// </summary>
        /// <param name="source">Points which are verified</param>
        /// <param name="rows">Height of the image</param>
        /// <returns>True if the parameters needs to be recalculated</returns>
        private bool CheckOrder(List<Point3D> source, int rows)
        {
            List<Point3D> weightListMin2 = Geometry.CloneList(source);
            ImageProcessing.ConvertXY(weightListMin2, rows);
            Point3D pMinus = new Point3D(weightListMin2[0]);
            Geometry.p_add(weightListMin2, pMinus, -1d);
            Point3D rotZsc = Geometry.calc_rotZ(weightListMin2[1]);
            Geometry.p_rotZ(weightListMin2, rotZsc, -1d);

            if (weightListMin2[2].Y < 0)
            {
                source.Reverse(1, source.Count - 1);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// Find the location of the first always black spot
        /// </summary>
        /// <param name="binarPlaces">Five projected probable locations</param>
        /// <param name="original">The source image, where the spots will be searched</param>
        /// <returns>Location on the image and its number</returns>
        private WeightCenter FindBinaryPlace(byte[, ,] original, List<Point3D> binarPlaces)
        {
            int sumMin = 765; // 255 * 3 - the max sum possible
            int sum;
            byte R, G, B; // b0g1r2
            Point3D pMin = null;
            int foundedPosition = 0;
            for (int i = 0; i < 5; i++)
            {
                if ((binarPlaces[i].X < 0) || (binarPlaces[i].Y < 0))
                    return WeightCenter.Empty;
                R = original[(int)binarPlaces[i].Y, (int)binarPlaces[i].X, 2];
                G = original[(int)binarPlaces[i].Y, (int)binarPlaces[i].X, 1];
                B = original[(int)binarPlaces[i].Y, (int)binarPlaces[i].X, 0];
                sum = R + G + B;
                if (sum < sumMin) // Find the darkest spot
                {
                    foundedPosition = i;
                    sumMin = sum;
                    pMin = binarPlaces[i];
                }
            }
            WeightCenter w = new WeightCenter((int)pMin.X, (int)pMin.Y, foundedPosition);

            //Visualization.VisualizeWeightCenter(w, imgOriginal.Data, FrameRows, FrameCols, 100);
            //Visualization.VisualizeWeightCenter(w, imgR.Data, FrameRows, FrameCols);

            return new WeightCenter((int)pMin.X, (int)pMin.Y, foundedPosition);
        }

        /// <summary>
        /// Read the binary code with the formula: C1*1 + C2*2 + C5*4 + C6*8
        /// First point is always black, fifth point is always white
        /// </summary>
        /// <param name="original"></param>
        /// <param name="binLocations"></param>
        /// <returns>The number of detected side</returns>
        private int ReadBinaryCode(byte[, ,] original, List<Point3D> binLocations)
        {
            byte[] binaryCode = new byte[8];
            byte R, G, B; // b0g1r2
            int sum, sideNumber;

            // Read the binary code
            for (int i = 0; i < 8; i++)
            {
                if (binLocations == null)
                    return -1;
                if ((binLocations[i].Y < 0) || (binLocations[i].X < 0))
                    return -1;

                R = original[(int)binLocations[i].Y, (int)binLocations[i].X, 2];
                G = original[(int)binLocations[i].Y, (int)binLocations[i].X, 1];
                B = original[(int)binLocations[i].Y, (int)binLocations[i].X, 0];
                sum = R + G + B;
                if (sum < BW_LIMIT) // The spot is black
                    binaryCode[i] = 1;
                else
                    binaryCode[i] = 0;
            }

            // Check for correct order of binary code
            if (!CheckBinaryControlSum(binaryCode))
                return -1;

            sideNumber = binaryCode[1] + binaryCode[2] * 2 +
                binaryCode[5] * 4 + binaryCode[6] * 8;
            if ((sideNumber < 1) || (sideNumber > 12))
            {
                sideNumber = -1; // Sometimes the binary code is read wrong
            }
            return sideNumber;
        }

        /// <summary>
        /// Calculate the exact 8 locations of binary code for reading
        /// </summary>
        /// <param name="original">Frame from which will be founded the always first black spot</param>
        /// <param name="sourceBinPars">Orientation parameters of descriptor</param>
        /// <param name="destBinPars">Orientation parameters of projection from camera</param>
        /// <returns>Eight positions of binary code according projection</returns>
        private List<Point3D> CalcBinaryPlaces(byte[, ,] original, Point3D[] sourceBinPars, Point3D[] destBinPars, out WeightCenter binFound)
        {
            List<Point3D> binarPlacesHomography = Geometry.homography_calc(
                    new List<Point3D>(dataMouse.binarPlacesBase), sourceBinPars, destBinPars);
            binFound = FindBinaryPlace(original, binarPlacesHomography);
            if (binFound == WeightCenter.Empty)
                return null;

            List<Point3D> binar8Codes = new List<Point3D>(Geometry.CloneList(dataMouse.binarSpotsSide01));
            // Rotate the 8 binary codes according the founded position
            Geometry.p_rotZ(binar8Codes, dataMouse.SinCosDescriptor[binFound.rowStart], 1);
            binar8Codes = Geometry.homography_calc(binar8Codes, sourceBinPars, destBinPars);

            return binar8Codes;
        }

        /// <summary>
        /// Check whether the sum of first three black spots on first and second row is even or odd
        /// In case of even sum, the 8th bit should be black, otherwise the 4th
        /// </summary>
        /// <param name="binaryCode">The binary code which is verified</param>
        /// <returns>True if the sum is correct, false if not</returns>
        private bool CheckBinaryControlSum(byte[] binaryCode)
        {
            byte sum = 0;
            for (int i = 0; i <= 2; i++)
            {
                if (binaryCode[i] == 1)
                    sum++;
                if (binaryCode[i + 4] == 1)
                    sum++;
            }
            if (sum % 2 == 0) // Even
            {
                if (binaryCode[7] != 1)
                    return false;
            }
            else // Odd
            {
                if (binaryCode[3] != 1)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Check if side number corresponds to the color.
        /// </summary>
        /// <param name="sideNumber">Side Number</param>
        /// <param name="color">Color</param>
        /// <returns>True if pass</returns>
        private bool CheckSideNumberColor(int sideNumber, FilterColors color)
        {
            // Check the number of side
            if (color == FilterColors.R) // Check for Red and Yellow side
            {
                if ((sideNumber != 6) && (sideNumber != 7) && (sideNumber != 10))
                    return false;
            }

            if (color == FilterColors.Y) // Check for Red and Yellow side
            {
                if ((sideNumber != 1) && (sideNumber != 5) && (sideNumber != 11))
                    return false;
            }

            if (color == FilterColors.G)
            {
                if ((sideNumber != 8) && (sideNumber != 9) && (sideNumber != 12))
                {
                    //MessageBox.Show("sidenumber = " + sideNumber.ToString() + " color " + color.ToString());
                    return false;
                }
            }

            if (color == FilterColors.B)
            {
                if ((sideNumber != 2) && (sideNumber != 3) && (sideNumber != 4))
                {
                    //MessageBox.Show("sidenumber = " + sideNumber.ToString() + " color " + color.ToString());
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Get the rotation angles by X, Y, Z axis of 4 points
        /// representing the coordinate system of an object
        /// </summary>
        /// <param name="sourceInput">Center, X, Y, Z points of the coordinate system of the object</param>
        /// <returns>Three Sin and Cos by X, Y, Z axis</returns>
        public static List<Point3D> GetRotationAngles(List<Point3D> sourceInput)
        {
            List<Point3D> source = Geometry.CloneList(sourceInput);
            Geometry.p_add(source, source[0].Clone(), -1);

            Point3D ySinCos = Geometry.calc_rotY(source[1]);
            Geometry.p_rotY(source, ySinCos, -1);

            Point3D zSinCos = Geometry.calc_rotZ(source[1]);
            Geometry.p_rotZ(source, zSinCos, -1);

            Point3D xSinCos = Geometry.calc_rotX(source[2]);
            Geometry.p_rotX(source, xSinCos, -1);

            List<Point3D> result = new List<Point3D>(3);
            result.Add(xSinCos);
            result.Add(ySinCos);
            result.Add(zSinCos);
            return result;
        }
    }
}
