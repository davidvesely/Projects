﻿using System;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;
using CADBest.Geometry;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;
using System.Collections.Generic;
using System.Windows;
using SixDoFMouse.CameraDetection;
using System.Drawing;
using System.Threading;

[assembly: CommandClass(typeof(SixDoFMouse.MyCommands))]

namespace SixDoFMouse
{
    public class MyCommands
    {
        [CommandMethod("PANEL6DOF", CommandFlags.Modal)]
        public void MyCommand()
        {
            FormControls form = new FormControls();
            form.Show();
        }

        [CommandMethod("TESTLOADFRAME", CommandFlags.Modal)]
        public void TestLoadFrame()
        {
            //string fileName = ImageProcessing.OpenImageFile();
            //if (fileName != string.Empty)
            //{
            //    FormStaticFrame staticFrameForm = new FormStaticFrame();
            //    staticFrameForm.SetPicture(fileName);
            //    staticFrameForm.Show();
            //}
            Point3D SinCos = new Point3D(0, 1, 0);
            double angle = Geometry.CalculateAngle(SinCos);
            int angleDeg = Geometry.ConvertToDeg(angle);

            SinCos = new Point3D(1, 0, 0);
            angle = Geometry.CalculateAngle(SinCos);
            angleDeg = Geometry.ConvertToDeg(angle);

            SinCos = new Point3D(0, -1, 0);
            angle = Geometry.CalculateAngle(SinCos);
            angleDeg = Geometry.ConvertToDeg(angle);

            SinCos = new Point3D(-1, 0, 0);
            angle = Geometry.CalculateAngle(SinCos);
            angleDeg = Geometry.ConvertToDeg(angle);
        }

        [CommandMethod("TEST_VIEWDIR_X", CommandFlags.Modal)]
        public void TestViewDirX()
        {
            TestViewDir(ScreenAxisRotation.SideAxis);
        }

        [CommandMethod("TEST_VIEWDIR_Y", CommandFlags.Modal)]
        public void TestViewDirY()
        {
            TestViewDir(ScreenAxisRotation.UpAxis);
        }

        public void TestViewDir(ScreenAxisRotation axis)
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            ViewTableRecord vtr = doc.Editor.GetCurrentView();

            Vector3d dirVector = vtr.ViewDirection;
            Vector3d sideVectorAxis = vtr.ViewDirection.GetPerpendicularVector();
            Vector3d upVectorAxis = dirVector.CrossProduct(sideVectorAxis).GetNormal();

            Vector3d axisRotation = new Vector3d();
            switch (axis)
            {
                case ScreenAxisRotation.SideAxis:
                    axisRotation = sideVectorAxis;
                    break;
                case ScreenAxisRotation.UpAxis:
                    axisRotation = upVectorAxis;
                    break;
                case ScreenAxisRotation.Twist:
                    break;
                default:
                    break;
            }

            for (int i = 0; i < 72; i++)
            {
                Thread.Sleep(50);

                // Rotation
                vtr.ViewDirection = vtr.ViewDirection.RotateBy(0.0872664626, axisRotation);

                dirVector = vtr.ViewDirection;
                Vector3d sideVector = vtr.ViewDirection.GetPerpendicularVector();
                Vector3d upVector = dirVector.CrossProduct(sideVector).GetNormal();

                // Calculate the actual upVector,
                // by applying the view transformation
                Matrix3d WCS2DCS = doc.Editor.WCS2DCS();
                Vector3d upVectorDCS = upVector.TransformBy(WCS2DCS);

                // Get the twist angle
                double safeViewTwist = Math.Atan2(upVectorDCS[1], upVectorDCS[0]) - Math.PI / 2;
                if (safeViewTwist < -1e-6)
                    safeViewTwist += (Math.PI * 2.0);

                vtr.ViewTwist = safeViewTwist;
                doc.Editor.SetCurrentView(vtr);
                doc.Editor.Regen();
            }
        }
    }
}