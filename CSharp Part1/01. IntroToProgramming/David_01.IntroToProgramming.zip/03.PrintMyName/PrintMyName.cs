﻿// Modify the application to print your name

using System;

class PrintMyName
{
    static void Main()
    {
        Console.WriteLine("Hi there, my name is David Vesely.");
    }
}
