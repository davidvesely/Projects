﻿// Create console application that prints your first and last name

using System;

class PrintFirstLastName
{
    static void Main()
    {
        Console.WriteLine("David Vesely");
    }
}
